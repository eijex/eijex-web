# FactorForgeFormal — Lean 4.36.0 Formal Verification Package

Standalone Lean 4 formal verification package for FactorForge's exact finite-state dynamic programming (DP) core, standard genetic code amino-acid preservation, constructive DP backtracking, and quantized/floating-point score margin exactness.

## Toolchain
- **Lean:** `leanprover/lean4:v4.36.0` (commit `611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9`)
- **Lake:** `5.0.0`
- **Independent Kernel Checker:** `leanchecker` (`lake env leanchecker FactorForgeFormal`)
- **Zero External Dependencies:** Pure Lean 4 core (`0 sorry`, `0` custom `axiom`s, `0 native_decide`).

## Directory Structure
- `spec_lock_manifest.json` — SHA-256 lock digests of all 6 specification modules (`Spec/*.lean` and `Spec.lean`).
- `FactorForgeFormal/Spec/` — Locked mathematical specifications:
  - `Tropical.lean` — Tropical max-plus semiring `Trop Int` and order laws.
  - `Automaton.lean` — Construct-level finite-state automaton transitions and safety invariants.
  - `GeneticCode.lean` — Full 64-triplet Standard Genetic Code (`61` sense + `3` stop) and `translateDNA`.
  - `ExactDP.lean` — `ValidCodonForAA`, `WellFormedMenu`, `ValidPath`, `dpEval`, `dpBestScore`, constructive backtracking `dpOptimize`, and end-to-end synonymous optimality propositions.
  - `KineticAndParity.lean` — `ExactRat` TASEP ramp interpolation, zero-weight pause parity, `pathLexLt` strict total order, and `Prop_ApproxScoreExactness`.
- `FactorForgeFormal/Proofs/` — Complete kernel-checked proofs of all 20 core theorems.
- `FactorForgeFormal/Witnesses.lean` — 14 non-vacuity witnesses and malformed-input refutations (including refutation of `AAA` with fake `gc = 3`, stop-codon rejection, and full BsaI construct `"GGTC" + "SL" + "TAA"` backtracking).
- `FactorForgeFormal/Audit.lean` — `#print axioms` audit across all 34 theorem and witness declarations.

## Reproducing Verification
```powershell
$env:PATH = "$env:USERPROFILE\.elan\bin;$env:PATH"
lake clean
lake build
lake env leanchecker FactorForgeFormal
```
