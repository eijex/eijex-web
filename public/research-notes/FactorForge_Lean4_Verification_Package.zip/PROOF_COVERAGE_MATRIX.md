# FactorForge Mathematical Formulation & Proof Coverage Matrix

Date: 2026-11-25  
Related Jobs: Job 710 (`710-lean4-dp-formal-verification`), Job 711 (`711-lean4-implementation-correspondence-and-packaging`)  
Epistemic Boundary: `UNVERIFIED_PUBLIC_CORPUS · Biological validation: NOT_AVAILABLE`

---

## Purpose

Not every mathematical formula in a codon optimization system belongs to the same verification category. Definitional metrics, heuristic baseline generators, exact dynamic programming recurrences, and benchmark summary statistics require distinct verification methods. This matrix maps all **28 mathematical formulations (F1–F28)** across FactorForge's five functional groups to:

1. **Lean 4 Specification & Proved Theorems** (`formal/FactorForgeFormal/`),
2. **Production Python Modules & Functions** (`factorforge/src/factorforge/`), and
3. **Verification Tier & Honest Residual Boundary**.

---

## Verification Tiers

- **Tier L1 — Lean 4 Kernel Proof (`0 sorry`, `leanchecker` verified):** Universal mathematical proof over all inputs of arbitrary length in Lean 4.36.0.
- **Tier O1 — Exhaustive Brute-Force + Property + Mutation Oracle:** Verified in Python against naive Cartesian-product enumeration (`BruteForceCDSOracle`), exact integer mirror (`LeanExactMirrorDP`), 200-instance seeded shrinking property fuzzer, and 8/8 semantic mutant kills.
- **Tier C1 — Deterministic Metric / Contract Unit Suite:** Verified by deterministic unit and regression suites in `factorforge/tests/` (definitional identities, heuristic generators, and statistical aggregations).
- **Boundary B — Explicit Runtime Divergence Documented:** Known difference between discrete Lean arithmetic (`Trop Int`, `ExactRat`) and Python runtime (`float`, `1e-12` epsilon tie window, `round(..., 3)` smoothing, heuristic pruning), pinned by explicit regression tests.

---

## Coverage Matrix (Formulations F1–F28)

### Group I — Sequence Metrics & Objective Primitives (F1–F4)

| ID | Mathematical Formulation | Lean 4 Symbol / Theorem | Python Implementation | Tier | Notes & Boundary |
|---|---|---|---|---|---|
| **F1** | Empirical codon frequency $f(c)$ per synonymous family | Modeled via external weight input (`CodonSpec.score`) | `analysis/metrics.py`: `load_codon_usage_table`, `codon_usage_profile` | **C1** | Empirical table loader; validated via schema & reference-hash tests. |
| **F2** | Relative adaptiveness $w(c) = f(c) / \max_{c' \in \text{Syn}(a)} f(c')$ | Input to fixed-point quantizer (`CanonicalQuantizer`) | `analysis/metrics.py`: `_build_codon_weights` | **C1 + O1** | `float` division in `[0, 1]`; clamped at `1e-6` before `math.log` in `dp_v2.py`. |
| **F3** | Geometric-mean CAI $\exp(\frac{1}{L}\sum_{i=1}^L \ln w(c_i))$ & additive log-score | `pathScore`, `Prop_ApproxScoreExactness` (`approxScoreExactness`) | `analysis/metrics.py`: `calculate_cai`; `scoring/quantization.py`: `CanonicalQuantizer` | **L1 + O1 (Boundary B)** | Lean proves additive integer optimality and conditional bounded-integer-perturbation ordering; `exp(score/L)` monotone transform is `float` in Python. |
| **F4** | Nucleotide GC count & percentage $\frac{100}{3L}\sum_{j=1}^{3L}\mathbf{1}_{b_j \in \{G,C\}}$ | `Base.gcCount`, `seqGC`, `pathGC`, `gcConservation` | `analysis/metrics.py`: `calculate_gc` | **L1 + O1** | Exact integer nucleotide GC conservation proved in `gcConservation` & `proteinPreservationAndGC`. |

---

### Group II — Synonymous Design Space & Construct Feasibility (F5–F9)

| ID | Mathematical Formulation | Lean 4 Symbol / Theorem | Python Implementation | Tier | Notes & Boundary |
|---|---|---|---|---|---|
| **F5** | Standard 64-triplet Genetic Code $\mathcal{G}: \{A,C,G,T\}^3 \to \mathcal{A} \cup \{\text{stop}\}$ | `Spec/GeneticCode.lean`: `translateTriplet`, `geneticCodePartition64` | `analysis/metrics.py`: `STANDARD_GENETIC_CODE`, `STOP_CODONS` | **L1 + O1** | 64-for-64 bijection verified automatically by `test_lean_genetic_code_exact_64_codon_bijection_with_python` (`61` sense + `3` stop). |
| **F6** | Sense CDS translation & amino-acid sequence preservation $\text{Translate}(C) = P$ | `ValidCodonForAA`, `WellFormedMenu`, `translateDNA`, `proteinPreservationAndGC` | `analysis/metrics.py`: `translate_dna`, `amino_acid_identity`, `count_internal_stops` | **L1 + O1** | `WellFormedMenu` enforces menu soundness (`∀ c ∈ opts, ValidCodonForAA c a = true`, blocking `AAA`/`gc=3` and stops), while Python table construction supplies the runtime menus; `witness_sl_wellFormedMenu` checks only the concrete `SL` menu. |
| **F7** | Forbidden motif set $\mathcal{M}$ with reverse-complement closure $\mathcal{M} \cup \overline{\mathcal{M}}^{\text{RC}}$ | `Automaton`, `bsaiAutomaton` (`Witnesses.lean`) | `constraints/type_iis.py`; `sllm/automaton.py`: `AutomatonCompiler.compile` | **L1 (DFA) + O1 (Substring)** | Lean models abstract DFA execution; `BruteForceCDSOracle` cross-checks Aho-Corasick DFA directly against raw substring search. (`PYTHONHASHSEED` state-ID permutation documented in **Boundary B**.) |
| **F8** | Full-construct concatenation safety across $F_L \mathbin{\Vert} \text{CDS} \mathbin{\Vert} F_R$ | `stepSeqAppend`, `safeSeqAppend`, `stepCodonSafeSound`, `stepCodonSafeComplete`, `fullConstructSafe` | `dp_v2.py` (`left_flank`, `step_codon`, `right_flank` filter) | **L1 + O1** | Proved for arbitrary flank and CDS lengths; junction and cross-bridge motifs verified against brute-force substring oracle. |
| **F9** | Construct-feasible synonymous set $\mathcal{F}(P, \theta)$ (GC band `[minGC, maxGC]` + motif-free) | `FeasibleCDS`, `WellFormedMenu`, `synonymousEnvelopeUnsat` | `dp_v2.py`: `min_gc_count`, `max_gc_count`, `in_band_candidates` | **L1 + O1** | Exact integer GC band `[ceil(gc_min * 3L), floor(gc_max * 3L)]` matched identically in `BruteForceCDSOracle` and `LeanExactMirrorDP`. |

---

### Group III — Heuristic & Rule-Based Baseline Generators (F10–F14)

| ID | Mathematical Formulation | Lean 4 Symbol / Theorem | Python Implementation | Tier | Notes & Boundary |
|---|---|---|---|---|---|
| **F10** | Uniform / seeded synonymous random sampling | Not a global optimality target (stochastic baseline) | `engines/profile/rules/reverse_translator.py` | **C1** | Verified for amino-acid preservation and seed reproducibility in unit tests. |
| **F11** | Greedy maximum-CAI reverse translation (`high_cai`) | Unconstrained special case ($M$ trivial, `[0, 3L]`) | `engines/profile/rules/reverse_translator.py` | **C1** | Maximizes per-residue weight without global GC or cross-junction lookahead. |
| **F12** | Frequency-balanced synonymous selection (`balanced`) | Not modeled in Lean (heuristic) | `engines/balanced_optimizer.py`, `reverse_translator.py` | **C1** | Heuristic usage-matching baseline; no global optimality claimed. |
| **F13** | Greedy GC-target selection (`gc_target`) & local domestication | Not modeled in Lean (greedy local repair) | `engines/profile/rules/domesticator.py`, `reverse_translator.py` | **C1** | Local greedy substitution; can fail on coupled GC + junction constraints where exact DP succeeds. |
| **F14** | SOP multi-objective heuristic balancer / local exit-tunnel rewriter | Not modeled in Lean (heuristic post-processor) | `codon/sop_balancer.py`, `engines/local_rewriter.py` | **C1** | Evaluated empirically under shared evaluator gates; outside exact DP theorem scope. |

---

### Group IV — Exact Finite-State Dynamic Programming & Kinetic Extensions (F15–F19)

| ID | Mathematical Formulation | Lean 4 Symbol / Theorem | Python Implementation | Tier | Notes & Boundary |
|---|---|---|---|---|---|
| **F15** | Tropical max-plus algebra $(\mathbb{Z} \cup \{-\infty\}, \oplus, \otimes)$ & DP state lattice $(i, g, s)$ | `Spec/Tropical.lean`: `tropIntSemiringLaws`, `tropIntOrderLaws`; `dpBase`, `dpTrackBase` | `dp_v2_4.py`: `TropicalSemiring`; `dp_v2.py`: `dp_layers[0]` | **L1 + O1** | All 12 semiring + order laws kernel-proved. |
| **F16** | Forward Bellman transition over $(g', s')$ with hard automaton veto | `dpStep`, `dpEval`, `dpSoundness`, `dpCompleteness` | `dp_v2.py:84-135`, `dp_v2_3.py`, `dp_v2_4.py` | **L1 + O1 (Boundary B)** | Soundness & completeness kernel-proved over `Trop Int`. Python uses `float` + `1e-12` tie window; initiation-ramp clamp (`dp_v2_3`/`dp_v2_4`) is outside `ExactDP.lean`. |
| **F17** | Right-flank terminal filter & in-band global optimum selection | `dpBestScore`, `exactGlobalOptimality`, `exactOpt_witness_eq` | `dp_v2.py:140-172` | **L1 + O1 (Boundary B)** | Global optimality over `FeasibleCDS` kernel-proved; nearest-infeasible fallback (`gc_feasible=False`) verified against `BruteForceCDSOracle`. |
| **F18** | Constructive witness-path extraction & separate lexicographic order laws | `dpTrackEval`, `dpOptimize`, `dpOptimizeEndToEnd`, `pathLexTotalOrder` | `dp_v2.py:188-203`; `scoring/quantization.py`: `PathRank` | **L1 + O1 (Boundary B)** | Lean keeps first-seen exact ties; the mirror and production use distinct tie policies. `dpOptimizeEndToEnd` proves the returned DNA sequence itself satisfies `translateDNA = some protein`, exact `seqGC`, full construct safety, and global score optimality. |
| **F19** | Suffix synonymous GC envelope pruning & TASEP upstream pause-ramp kinetics | `gcEnvelopeAndPruningAdmissible`, `tasepRampBoundsAndMonotonicity`, `zeroWeightParity` | `dp_v2_4.py`: `TASEPKineticsEngine.compute_smoothed_pause_map`, `compute_codon_log_fitness` | **L1 + O1 (Boundary B)** | Exact rational `ExactRat` interiority & monotonicity proved; Python `round(..., 3)` boundary near `1.0` pinned by regression test. |

---

### Group V — Shared Evaluator & Benchmark Aggregation Metrics (F20–F28)

| ID | Mathematical Formulation | Lean 4 Symbol / Theorem | Python Implementation | Tier | Notes & Boundary |
|---|---|---|---|---|---|
| **F20** | Candidate hard-constraint pass indicator $\mathbb{I}_{\text{pass}}(C) \in \{0,1\}$ | Mirrors `FeasibleCDS ∧ translateDNA = some protein` | `evaluation/evaluator.py`: `SharedEvaluator.evaluate_candidate` | **C1 + O1** | Includes additional expression/synthesis risk checks (homopolymers, MFE windows) beyond core DP constraints. |
| **F21** | Sliding-window & 5'-region GC metrics | Not modeled in Lean (post-generation diagnostic) | `analysis/metrics.py`: `calculate_gc_windows`, `calculate_first_region_gc` | **C1** | Definitional window averages verified in metric unit tests. |
| **F22** | Homopolymer run-length detector ($\ge 6$ nt expression / $\ge 8$ nt synthesis) | Not modeled in Lean | `analysis/metrics.py`: `detect_homopolymers` | **C1** | Deterministic linear scan verified in unit tests. |
| **F23** | Dinucleotide avoidance score (`CpG` / `TpA` ratio) | Not modeled in Lean | `analysis/metrics.py`: `calculate_dinucleotide_score` | **C1** | Definitional formula verified in unit tests. |
| **F24** | Suite pass rate $\frac{1}{N}\sum_{k=1}^N \mathbb{I}_{\text{pass}}(C_k)$ | Statistical summary (out of scope for Lean) | `benchmark/runner.py`: `BenchmarkRunner._aggregate_results` | **C1** | Arithmetic aggregation over finite target list. |
| **F25** | Suite mean / dispersion of CAI and GC% across targets | Statistical summary (out of scope for Lean) | `benchmark/runner.py`: `BenchmarkRunner._aggregate_results` | **C1** | Arithmetic mean over benchmark suite outputs. |
| **F26** | Mutually exclusive / multi-label constraint failure taxonomy | Diagnostic categorization | `evaluation/evaluator.py`, `evaluation/models.py` | **C1** | Verified in evaluator contract tests. |
| **F27** | SHA-256 input & provenance digest binding | Enforced externally via `spec_lock_manifest.json` & `REPRODUCIBILITY_MANIFEST.json` | `benchmark/runner.py`, `scoring/quantization.py`: `compute_digest` | **C1 + O1** | Cryptographic SHA-256 verification enforced fail-closed in `verify_all.py`. |
| **F28** | Epistemic classification gate (`UNVERIFIED_PUBLIC_CORPUS`, `Biological validation: NOT_AVAILABLE`) | Governance & schema invariant | `schemas/evidence.py`, `validation_registry.py` | **C1** | Hard governance boundary: mathematical/computational proofs never imply wet-lab expression success. |

## Job 712 review: exact proof boundary (2026-11-25)

The Lean kernel checks the declared discrete model. It does not prove a refinement theorem
from Python execution to Lean, and the Python mirror is another tested implementation,
not extracted Lean code. The 200 generated cases and 8 killed mutants describe this finite
suite; the mutants are injected into a reference copy, not production source mutations.

Three selection policies remain distinct: Lean `relaxCand` keeps the first enumerated
candidate on an exact score tie; the integer Python mirror uses full-prefix `PathRank`;
production DP uses last-codon comparison within a `1e-12` window and its own final-state
selection. `pathLexTotalOrder` proves an independent comparator's order laws. It does not
prove that `dpOptimize` returns the lexicographically smallest optimum. The constructive
Lean optimizer stores whole prefix paths; production reconstructs stored backpointers.
Score-optimal witness extraction is proved for the former, with the latter tested separately.

`Prop_ApproxScoreExactness` is a conditional perturbation theorem over lists of **Int**.
It assumes bounded errors; it does not establish a binary64 `math.log` error bound,
real logarithm semantics, quantizer scaling correctness, or the cumulative loss caused by
production epsilon-based relaxation. Consequently its `2 * L * eps` argument alone is
not a certificate for arbitrary production floating-point inputs. The fuzzer's margin
comparisons are observations on sampled inputs.

Optimality is relative to the supplied codon menus and additive integer scores.
`WellFormedMenu` establishes soundness, not completeness of all synonymous alternatives;
the `SL` witness demonstrates one menu, not universal menu completeness. Abstract DFA
safety assumes the supplied transition/terminal specification; no general Lean theorem
here proves that Python's compiler recognizes every arbitrary forbidden-substring set.
The C1 rows in the coverage matrix identify external suites, not suites executed by this
package. No biological mechanism or expression outcome follows from these proofs.
