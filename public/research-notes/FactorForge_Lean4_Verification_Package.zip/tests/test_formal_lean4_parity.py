"""Fail-closed Lean 4 kernel, SHA-256 spec lock, and genetic-code bijection tests."""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
FORMAL_ROOT = PACKAGE_ROOT / "formal"
SPEC_LOCK_PATH = FORMAL_ROOT / "spec_lock_manifest.json"
FACTORFORGE_SRC = PACKAGE_ROOT / "factorforge_snapshot" / "src"
if str(FACTORFORGE_SRC) not in sys.path:
    sys.path.insert(0, str(FACTORFORGE_SRC))

from factorforge.analysis.metrics import STANDARD_GENETIC_CODE
from factorforge.engines.dp_v2 import DPV2Optimizer
from factorforge.engines.dp_v2_4 import (
    DPV240Optimizer,
    TASEPKineticsEngine,
    TropicalSemiring,
)
from factorforge.engines.sllm.automaton import AutomatonCompiler
from factorforge.scoring.quantization import CanonicalQuantizer, PathRank

from .oracle_helpers import compile_deterministic_automaton


def _find_lean_tool(name: str) -> str | None:
    found = shutil.which(name)
    if found:
        return found
    candidate = Path.home() / ".elan" / "bin" / f"{name}.exe"
    if candidate.exists():
        return str(candidate)
    candidate_unix = Path.home() / ".elan" / "bin" / name
    if candidate_unix.exists():
        return str(candidate_unix)
    return None


def test_formal_spec_sha256_lock_integrity() -> None:
    """Verify all 6 locked Lean specification files match spec_lock_manifest.json."""
    assert SPEC_LOCK_PATH.exists(), f"Missing spec lock manifest: {SPEC_LOCK_PATH}"
    expected = json.loads(SPEC_LOCK_PATH.read_text(encoding="utf-8-sig"))
    assert set(expected.keys()) == {
        "Tropical.lean",
        "Automaton.lean",
        "GeneticCode.lean",
        "ExactDP.lean",
        "KineticAndParity.lean",
        "Spec.lean",
    }
    for filename, expected_hash in expected.items():
        if filename == "Spec.lean":
            path = FORMAL_ROOT / "FactorForgeFormal" / "Spec.lean"
        else:
            path = FORMAL_ROOT / "FactorForgeFormal" / "Spec" / filename
        assert path.exists(), f"Missing spec file: {path}"
        actual_hash = hashlib.sha256(path.read_bytes()).hexdigest().upper()
        assert actual_hash == expected_hash.upper(), (
            f"Spec file {filename} drifted from locked SHA-256!"
        )


def test_lean_genetic_code_exact_64_codon_bijection_with_python() -> None:
    """Independently parse Spec/GeneticCode.lean and prove 64-codon identity with Python."""
    lean_gc_path = FORMAL_ROOT / "FactorForgeFormal" / "Spec" / "GeneticCode.lean"
    text = lean_gc_path.read_text(encoding="utf-8")

    # Match rules like: | .T, .T, .T => .aa .F  or  | .T, .A, .A => .stop
    pattern = re.compile(
        r"\|\s*\.([ACGT])\s*,\s*\.([ACGT])\s*,\s*\.([ACGT])\s*=>\s*(?:\.aa\s+\.([A-Z])|(\.stop))"
    )
    parsed: dict[str, str] = {}
    for b1, b2, b3, aa_sym, stop_sym in pattern.findall(text):
        codon = f"{b1}{b2}{b3}"
        assert codon not in parsed, f"Duplicate codon pattern in Lean: {codon}"
        parsed[codon] = "*" if stop_sym == ".stop" else aa_sym

    assert len(parsed) == 64, f"Expected 64 triplets in GeneticCode.lean, got {len(parsed)}"
    assert parsed == STANDARD_GENETIC_CODE, (
        "Mismatch between Lean Spec/GeneticCode.lean and Python STANDARD_GENETIC_CODE!"
    )
    assert sum(1 for v in parsed.values() if v != "*") == 61
    assert sum(1 for v in parsed.values() if v == "*") == 3


def test_formal_lean_files_contain_no_cheat_constructs() -> None:
    """Ensure zero sorry, admit, custom axiom, unsafe, partial, or native_decide."""
    lean_files = sorted((FORMAL_ROOT / "FactorForgeFormal").rglob("*.lean"))
    assert len(lean_files) >= 13
    banned_patterns = [
        re.compile(r"\bsorry\b"),
        re.compile(r"\badmit\b"),
        re.compile(r"(?m)^\s*axiom\b"),
        re.compile(r"\bunsafe\b"),
        re.compile(r"\bpartial\b"),
        re.compile(r"\bnative_decide\b"),
        re.compile(r"\bLean\.ofReduceBool\b"),
    ]
    for path in lean_files:
        text = path.read_text(encoding="utf-8")
        stripped = re.sub(r"/-.*?-/", "", text, flags=re.DOTALL)
        stripped = re.sub(r"--[^\n]*", "", stripped)
        for pat in banned_patterns:
            assert pat.search(stripped) is None, f"Banned token {pat.pattern} found in {path}"


def test_bsai_automaton_and_dp_witness_match_lean() -> None:
    """Cross-check FactorForge Python DFA + DPV2Optimizer against Lean Witnesses.lean."""
    auto = AutomatonCompiler.compile(["GGTCTC"], include_rc=True)
    assert auto.state_counter + 1 == 12
    assert len(auto.terminal_states) == 2

    s = 0
    for ch in "GGTC":
        s = auto.step_nucleotide(s, ch)
        assert s not in auto.terminal_states

    for forbidden_ser in ("TCT", "TCC", "TCA", "TCG"):
        next_s, is_forbidden = auto.step_codon(s, forbidden_ser)
        assert is_forbidden is True
        assert next_s in auto.terminal_states

    for safe_ser in ("AGC", "AGT"):
        next_s, is_forbidden = auto.step_codon(s, safe_ser)
        assert is_forbidden is False
        assert next_s not in auto.terminal_states

    # Deterministic sorted ["GAGACC", "GGTCTC"] / ["GGTCTC", "GAGACC"] trie verification
    det_auto = compile_deterministic_automaton(["GGTCTC"], include_rc=True)
    assert len(det_auto.terminal_states) == 2

    weights = {
        "TCT": 0.8,
        "TCC": 0.6,
        "TCA": 0.5,
        "TCG": 0.2,
        "AGT": 0.4,
        "AGC": 0.7,
        "TTA": 0.3,
        "TTG": 0.5,
        "CTT": 0.7,
        "CTC": 0.9,
        "CTA": 0.2,
        "CTG": 1.0,
    }
    q = CanonicalQuantizer(scale=1000)
    assert q.quantize(math.log(weights["AGC"])) + q.quantize(math.log(weights["CTG"])) == -357

    opt = DPV2Optimizer(forbidden_motifs=["GGTCTC"], include_reverse_complement=True)
    res = opt.optimize(
        "SL",
        weights,
        target_gc_min=0.33,
        target_gc_max=0.67,
        left_flank="GGTC",
        right_flank="TAA",
    )
    assert res["sequence"] == "AGCCTG"
    assert res["gc_feasible"] is True
    full_construct = "GGTC" + res["sequence"] + "TAA"
    assert "GGTCTC" not in full_construct
    assert "GAGACC" not in full_construct


def test_tasep_ramp_and_tropical_python_parity() -> None:
    """Verify TASEPKineticsEngine ramp bounds and TropicalSemiring match Lean proofs."""
    assert TropicalSemiring.oplus(TropicalSemiring.ZERO, 42.0) == 42.0
    assert TropicalSemiring.otimes(TropicalSemiring.ZERO, 42.0) == TropicalSemiring.ZERO
    assert TropicalSemiring.otimes(TropicalSemiring.ONE, 42.0) == 42.0

    smoothed = TASEPKineticsEngine.compute_smoothed_pause_map(
        "MAAAA",
        {5: [("TM", 3.0, 0.35)]},
        smoothing_window=3,
    )
    tau_d1 = smoothed[4][0][2]
    tau_d2 = smoothed[3][0][2]
    assert 0.35 < tau_d1 < tau_d2 < 1.0

    assert DPV240Optimizer(pause_positions=[5], pause_penalty_weight=0.0).compute_codon_log_fitness(
        4, "GCT", {"GCT": 0.8}, {}
    ) == DPV240Optimizer().compute_codon_log_fitness(4, "GCT", {"GCT": 0.8}, {})

    assert PathRank.compare_prefix_paths(["AGC", "CTG"], ["AGT", "CTG"]) == -1
    assert PathRank.compare_prefix_paths(["AGT", "CTG"], ["AGC", "CTG"]) == 1
    assert PathRank.compare_prefix_paths(["AGC", "CTG"], ["AGC", "CTG"]) == 0


def test_lean_kernel_and_axiom_audit_clean() -> None:
    """Fail-closed execution of `lake build` and `leanchecker` across all Lean modules."""
    allow_skip = os.environ.get("ALLOW_SKIP_LEAN_KERNEL") == "1"
    lake = _find_lean_tool("lake")
    leanchecker = _find_lean_tool("leanchecker")

    if lake is None or leanchecker is None:
        if allow_skip:
            pytest.skip("ALLOW_SKIP_LEAN_KERNEL=1 set and Lean toolchain not found")
        pytest.fail(
            "Fail-closed formal verification error: `lake` and `leanchecker` are required "
            "(set ALLOW_SKIP_LEAN_KERNEL=1 only in environments without Lean 4)."
        )

    env = os.environ.copy()
    elan_bin = str(Path.home() / ".elan" / "bin")
    env["PATH"] = f"{elan_bin}{os.pathsep}{env.get('PATH', '')}"

    # Rebuild Audit.lean fresh so `#print axioms` output is guaranteed emitted on stdout
    audit_olean = FORMAL_ROOT / ".lake" / "build" / "lib" / "lean" / "FactorForgeFormal" / "Audit.olean"
    if audit_olean.exists():
        audit_olean.unlink()

    build_proc = subprocess.run(
        [lake, "build"],
        cwd=str(FORMAL_ROOT),
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
    )
    assert build_proc.returncode == 0, build_proc.stdout + "\n" + build_proc.stderr
    assert "sorryAx" not in build_proc.stdout
    assert "uses `sorry`" not in build_proc.stdout
    assert "uses `sorry`" not in build_proc.stderr

    allowed = {"propext", "Classical.choice", "Quot.sound"}
    matches = re.findall(
        r"'([^']+)'\s+(?:depends on axioms:\s*\[([^\]]*)\]|(does not depend on any axioms))",
        build_proc.stdout,
    )
    assert len(matches) == 34, (
        f"Expected 34 #print axioms outputs from Audit.lean, got {len(matches)}\n"
        f"{build_proc.stdout}"
    )
    expected_decls = re.findall(
        r"(?m)^#print axioms (\S+)$",
        (FORMAL_ROOT / "FactorForgeFormal" / "Audit.lean").read_text(encoding="utf-8"),
    )
    actual_decls = [decl for decl, _, _ in matches]
    assert len(set(expected_decls)) == 34
    assert len(set(actual_decls)) == 34
    assert set(actual_decls) == set(expected_decls)
    for decl, ax_list, no_ax in matches:
        if not no_ax:
            used = {item.strip() for item in ax_list.split(",") if item.strip()}
            assert used <= allowed, f"Non-standard axiom on {decl}: {used}"

    chk_proc = subprocess.run(
        [lake, "env", leanchecker, "FactorForgeFormal"],
        cwd=str(FORMAL_ROOT),
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
    )
    assert chk_proc.returncode == 0, chk_proc.stdout + "\n" + chk_proc.stderr


def test_reproducibility_manifest_sha256_integrity() -> None:
    """Verify REPRODUCIBILITY_MANIFEST.json pins exact FactorForge and package file hashes."""
    from .test_verifier_regressions import verifier

    verifier._verify_reproducibility_manifest()
