"""Independent Brute-Force Oracle and Exact Integer Lean-Mirror Optimizer for FactorForge."""

from __future__ import annotations

import itertools
import math
import sys
from collections import deque
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path

FACTORFORGE_ROOT = Path(__file__).resolve().parents[1] / "factorforge_snapshot"
FACTORFORGE_SRC = FACTORFORGE_ROOT / "src"
if str(FACTORFORGE_SRC) not in sys.path:
    sys.path.insert(0, str(FACTORFORGE_SRC))

from factorforge.analysis.metrics import (
    STANDARD_GENETIC_CODE,
    translate_dna,
)
from factorforge.engines.sllm.automaton import CompiledAutomaton
from factorforge.scoring.quantization import CanonicalQuantizer, PathRank

AA_TO_SENSE_CODONS: dict[str, tuple[str, ...]] = {}
for _codon, _aa in sorted(STANDARD_GENETIC_CODE.items()):
    if _aa != "*":
        AA_TO_SENSE_CODONS.setdefault(_aa, ())
        AA_TO_SENSE_CODONS[_aa] = (*AA_TO_SENSE_CODONS[_aa], _codon)


def reverse_complement(seq: str) -> str:
    comp = {"A": "T", "T": "A", "C": "G", "G": "C"}
    return "".join(comp[ch] for ch in reversed(seq.upper()))


def expand_forbidden_motifs(motifs: Iterable[str], include_rc: bool = True) -> tuple[str, ...]:
    expanded = set()
    for raw in motifs:
        m = raw.strip().upper()
        if not m:
            continue
        expanded.add(m)
        if include_rc:
            expanded.add(reverse_complement(m))
    return tuple(sorted(expanded))


def has_any_substring_motif(full_dna: str, motifs: Sequence[str]) -> bool:
    dna = full_dna.upper()
    return any(m in dna for m in motifs)


@dataclass(frozen=True)
class BruteForceResult:
    feasible_any_gc: bool
    gc_feasible: bool
    best_score: float | None
    second_best_score: float | None
    best_sequences: tuple[str, ...]
    min_gc_count: int
    max_gc_count: int
    total_enumerated: int
    motif_safe_count: int
    in_band_count: int


class BruteForceCDSOracle:
    """Ground-truth exhaustive enumerator using raw substring checks (no Aho-Corasick)."""

    @staticmethod
    def solve(
        protein: str,
        codon_weights: dict[str, float],
        forbidden_motifs: Sequence[str] = (),
        include_rc: bool = True,
        target_gc_min: float = 0.40,
        target_gc_max: float = 0.47,
        left_flank: str = "",
        right_flank: str = "",
        score_tie_tol: float = 1e-12,
    ) -> BruteForceResult:
        prot = "".join(protein.upper().split()).rstrip("*")
        eff_motifs = expand_forbidden_motifs(forbidden_motifs, include_rc=include_rc)
        lf = left_flank.upper()
        rf = right_flank.upper()

        if has_any_substring_motif(lf, eff_motifs):
            raise ValueError(f"Left flank '{left_flank}' contains a forbidden motif.")

        total_nt = len(prot) * 3
        gc_min_frac = target_gc_min if target_gc_min <= 1.0 else target_gc_min / 100.0
        gc_max_frac = target_gc_max if target_gc_max <= 1.0 else target_gc_max / 100.0
        min_gc = math.ceil(gc_min_frac * total_nt)
        max_gc = math.floor(gc_max_frac * total_nt)

        menus = [AA_TO_SENSE_CODONS[aa] for aa in prot]
        codon_log = {
            c: math.log(max(codon_weights.get(c, 1e-4), 1e-6))
            for c, aa in STANDARD_GENETIC_CODE.items()
            if aa != "*"
        }

        total_enum = 0
        motif_safe: list[tuple[str, int, float]] = []
        for combo in itertools.product(*menus):
            total_enum += 1
            cds = "".join(combo)
            full_dna = lf + cds + rf
            if has_any_substring_motif(full_dna, eff_motifs):
                continue
            assert translate_dna(cds) == prot
            gc_cnt = cds.count("G") + cds.count("C")
            score = sum(codon_log[c] for c in combo)
            motif_safe.append((cds, gc_cnt, score))

        if not motif_safe:
            return BruteForceResult(
                feasible_any_gc=False,
                gc_feasible=False,
                best_score=None,
                second_best_score=None,
                best_sequences=(),
                min_gc_count=min_gc,
                max_gc_count=max_gc,
                total_enumerated=total_enum,
                motif_safe_count=0,
                in_band_count=0,
            )

        in_band = [(cds, gc, sc) for (cds, gc, sc) in motif_safe if min_gc <= gc <= max_gc]
        if in_band:
            best_sc = max(sc for _, _, sc in in_band)
            winners = tuple(
                sorted(cds for cds, _, sc in in_band if abs(sc - best_sc) <= score_tie_tol)
            )
            runners_up = [sc for _, _, sc in in_band if sc < best_sc - score_tie_tol]
            second_sc = max(runners_up) if runners_up else None
            return BruteForceResult(
                feasible_any_gc=True,
                gc_feasible=True,
                best_score=best_sc,
                second_best_score=second_sc,
                best_sequences=winners,
                min_gc_count=min_gc,
                max_gc_count=max_gc,
                total_enumerated=total_enum,
                motif_safe_count=len(motif_safe),
                in_band_count=len(in_band),
            )

        min_dist = min(
            min(abs(gc - min_gc), abs(gc - max_gc)) for _, gc, _ in motif_safe
        )
        nearest = [
            (cds, gc, sc)
            for (cds, gc, sc) in motif_safe
            if min(abs(gc - min_gc), abs(gc - max_gc)) == min_dist
        ]
        best_sc = max(sc for _, _, sc in nearest)
        winners = tuple(
            sorted(cds for cds, _, sc in nearest if abs(sc - best_sc) <= score_tie_tol)
        )
        runners_up = [sc for _, _, sc in nearest if sc < best_sc - score_tie_tol]
        second_sc = max(runners_up) if runners_up else None
        return BruteForceResult(
            feasible_any_gc=True,
            gc_feasible=False,
            best_score=best_sc,
            second_best_score=second_sc,
            best_sequences=winners,
            min_gc_count=min_gc,
            max_gc_count=max_gc,
            total_enumerated=total_enum,
            motif_safe_count=len(motif_safe),
            in_band_count=0,
        )


def compile_deterministic_automaton(
    motifs: Iterable[str], include_rc: bool = True
) -> CompiledAutomaton:
    """Compile Aho-Corasick DFA using sorted motif order (PYTHONHASHSEED-invariant)."""
    ordered = expand_forbidden_motifs(motifs, include_rc=include_rc)
    auto = CompiledAutomaton()
    for motif in ordered:
        curr = 0
        for ch in motif:
            if ch not in auto.transitions[curr]:
                auto.transitions[curr][ch] = auto.add_state()
            curr = auto.transitions[curr][ch]
        auto.terminal_states.add(curr)

    q_bfs: deque[int] = deque()
    for _, child in sorted(auto.transitions[0].items()):
        auto.fail_links[child] = 0
        q_bfs.append(child)

    while q_bfs:
        curr = q_bfs.popleft()
        if auto.fail_links[curr] in auto.terminal_states:
            auto.terminal_states.add(curr)
        for ch, child in sorted(auto.transitions[curr].items()):
            fs = auto.fail_links[curr]
            while fs != 0 and ch not in auto.transitions[fs]:
                fs = auto.fail_links[fs]
            auto.fail_links[child] = auto.transitions[fs].get(ch, 0)
            q_bfs.append(child)
    return auto


@dataclass(frozen=True)
class LeanMirrorResult:
    sequence: str
    quantized_score: int


class LeanExactMirrorDP:
    """Exact integer mirror of `FactorForgeFormal/Spec/ExactDP.lean:dpOptimize`."""

    def __init__(
        self,
        forbidden_motifs: Sequence[str] = (),
        include_rc: bool = True,
        scale: int = 1_000_000,
    ) -> None:
        self.automaton = compile_deterministic_automaton(forbidden_motifs, include_rc=include_rc)
        self.quantizer = CanonicalQuantizer(scale=scale)
        self.scale = scale

    def quantize_sequence_score(self, cds: str, codon_weights: dict[str, float]) -> int:
        total = 0
        for i in range(0, len(cds), 3):
            c = cds[i : i + 3]
            total += self.quantizer.quantize(math.log(max(codon_weights.get(c, 1e-4), 1e-6)))
        return total

    def optimize_exact(
        self,
        protein: str,
        codon_weights: dict[str, float],
        target_gc_min: float = 0.40,
        target_gc_max: float = 0.47,
        left_flank: str = "",
        right_flank: str = "",
    ) -> LeanMirrorResult | None:
        prot = "".join(protein.upper().split()).rstrip("*")
        lf = left_flank.upper()
        rf = right_flank.upper()

        s0 = 0
        for ch in lf:
            s0 = self.automaton.step_nucleotide(s0, ch)
            if s0 in self.automaton.terminal_states:
                return None

        total_nt = len(prot) * 3
        gc_min_frac = target_gc_min if target_gc_min <= 1.0 else target_gc_min / 100.0
        gc_max_frac = target_gc_max if target_gc_max <= 1.0 else target_gc_max / 100.0
        min_gc = math.ceil(gc_min_frac * total_nt)
        max_gc = math.floor(gc_max_frac * total_nt)

        layer: dict[tuple[int, int], tuple[int, list[str]]] = {(0, s0): (0, [])}

        for aa in prot:
            next_layer: dict[tuple[int, int], tuple[int, list[str]]] = {}
            for codon in AA_TO_SENSE_CODONS[aa]:
                assert len(codon) == 3
                assert STANDARD_GENETIC_CODE[codon] == aa
                c_gc = codon.count("G") + codon.count("C")
                q_score = self.quantizer.quantize(
                    math.log(max(codon_weights.get(codon, 1e-4), 1e-6))
                )

                for (g, s), (prev_sc, prev_path) in layer.items():
                    next_s, is_forbidden = self.automaton.step_codon(s, codon)
                    if is_forbidden:
                        continue
                    cand_key = (g + c_gc, next_s)
                    cand_sc = prev_sc + q_score
                    cand_path = [*prev_path, codon]
                    cur = next_layer.get(cand_key)
                    if cur is None:
                        next_layer[cand_key] = (cand_sc, cand_path)
                    else:
                        cur_sc, cur_path = cur
                        if cand_sc > cur_sc or (
                            cand_sc == cur_sc
                            and PathRank.compare_prefix_paths(cand_path, cur_path) < 0
                        ):
                            next_layer[cand_key] = (cand_sc, cand_path)
            layer = next_layer
            if not layer:
                return None

        feasible_finals: list[tuple[int, list[str]]] = []
        for (g, s), (sc, path) in layer.items():
            if not (min_gc <= g <= max_gc):
                continue
            curr = s
            ok = True
            for ch in rf:
                curr = self.automaton.step_nucleotide(curr, ch)
                if curr in self.automaton.terminal_states:
                    ok = False
                    break
            if ok:
                feasible_finals.append((sc, path))

        if not feasible_finals:
            return None

        feasible_finals.sort(
            key=lambda item: (-item[0], [PathRank.CODON_PRIORITY[c] for c in item[1]])
        )
        best_sc, best_path = feasible_finals[0]
        return LeanMirrorResult(
            sequence="".join(best_path),
            quantized_score=best_sc,
        )
