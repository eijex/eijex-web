"""Exhaustive Brute-Force Oracle, Seeded Property Fuzzing, and Implementation Boundary Tests."""

from __future__ import annotations

import math
import random

import pytest
from factorforge.analysis.metrics import (
    STANDARD_GENETIC_CODE,
    calculate_gc,
    count_internal_stops,
    translate_dna,
)
from factorforge.engines.dp_v2 import DPV2Optimizer
from factorforge.engines.dp_v2_3 import DPV230Optimizer
from factorforge.engines.dp_v2_4 import (
    DPV240Optimizer,
    TASEPKineticsEngine,
)

from .oracle_helpers import (
    AA_TO_SENSE_CODONS,
    BruteForceCDSOracle,
    LeanExactMirrorDP,
    expand_forbidden_motifs,
    has_any_substring_motif,
)


def _make_varied_weights(seed: int) -> dict[str, float]:
    rng = random.Random(seed)
    return {
        codon: round(rng.uniform(0.05, 1.0), 4)
        for codon, aa in sorted(STANDARD_GENETIC_CODE.items())
        if aa != "*"
    }


@pytest.mark.parametrize(
    ("protein", "motifs", "gc_min", "gc_max", "left_flank", "right_flank"),
    [
        ("MAVG", ["GGTCTC"], 0.50, 0.50, "", ""),
        ("FCIKM", ["GAAGAC"], 0.20, 0.40, "ATG", "TAA"),
        ("MWFIAL", ["GGTCTC", "CGTCTC"], 0.35, 0.65, "CCAT", "TGAG"),
        ("SRKDEV", ["GAATTC", "GGATCC"], 0.40, 0.55, "GAAT", "TCCG"),
        ("S", ["GGTCTC"], 0.0, 1.0, "GG", "C"),
        ("D", ["GGTCTC"], 0.0, 1.0, "GA", "C"),
        ("FFKK", ["GGTCTC"], 0.85, 0.95, "", ""),
        ("GGPP", ["GGTCTC"], 0.05, 0.15, "", ""),
        ("LLLL", ["AAAA", "CCCC", "TATA"], 0.30, 0.60, "AA", "CC"),
    ],
)
def test_dpv2_matches_exhaustive_bruteforce_across_boundaries(
    protein: str,
    motifs: list[str],
    gc_min: float,
    gc_max: float,
    left_flank: str,
    right_flank: str,
) -> None:
    """Verify DPV2Optimizer equals BruteForceCDSOracle across edge & junction cases."""
    weights = _make_varied_weights(seed=20261125)
    oracle = BruteForceCDSOracle.solve(
        protein=protein,
        codon_weights=weights,
        forbidden_motifs=motifs,
        include_rc=True,
        target_gc_min=gc_min,
        target_gc_max=gc_max,
        left_flank=left_flank,
        right_flank=right_flank,
    )
    opt = DPV2Optimizer(forbidden_motifs=motifs, include_reverse_complement=True)
    res = opt.optimize(
        protein,
        weights,
        target_gc_min=gc_min,
        target_gc_max=gc_max,
        left_flank=left_flank,
        right_flank=right_flank,
    )

    seq = res["sequence"]
    assert translate_dna(seq) == protein
    assert count_internal_stops(seq) == 0
    eff_motifs = expand_forbidden_motifs(motifs, include_rc=True)
    assert not has_any_substring_motif(left_flank + seq + right_flank, eff_motifs)
    assert res["gc_feasible"] is oracle.gc_feasible
    assert oracle.best_score is not None
    assert abs(res["score"] - oracle.best_score) <= 1e-11
    assert seq in oracle.best_sequences
    assert abs(res["gc_percent"] - calculate_gc(seq)) <= 1e-9


def test_equal_score_tie_breaking_and_unsatisfiable_automaton() -> None:
    """Verify deterministic tie-breaking on uniform weights and RuntimeError when 0 paths exist."""
    uniform_weights = {
        codon: 1.0 for codon, aa in STANDARD_GENETIC_CODE.items() if aa != "*"
    }
    opt = DPV2Optimizer(forbidden_motifs=["GGTCTC"], include_reverse_complement=True)
    res1 = opt.optimize("SLAV", uniform_weights, target_gc_min=0.40, target_gc_max=0.60)
    res2 = opt.optimize("SLAV", uniform_weights, target_gc_min=0.40, target_gc_max=0.60)
    assert res1["sequence"] == res2["sequence"]
    assert translate_dna(res1["sequence"]) == "SLAV"

    oracle = BruteForceCDSOracle.solve(
        "SLAV",
        uniform_weights,
        forbidden_motifs=["GGTCTC"],
        target_gc_min=0.40,
        target_gc_max=0.60,
    )
    assert res1["sequence"] in oracle.best_sequences
    assert abs(res1["score"] - (oracle.best_score or 0.0)) <= 1e-12

    impossible_opt = DPV2Optimizer(forbidden_motifs=["ATG"], include_reverse_complement=False)
    impossible_oracle = BruteForceCDSOracle.solve(
        "MA", uniform_weights, forbidden_motifs=["ATG"], include_rc=False
    )
    assert impossible_oracle.feasible_any_gc is False
    with pytest.raises(RuntimeError):
        impossible_opt.optimize("MA", uniform_weights)

    rf_opt = DPV2Optimizer(forbidden_motifs=["ATGCTC"], include_reverse_complement=False)
    rf_oracle = BruteForceCDSOracle.solve(
        "M", uniform_weights, forbidden_motifs=["ATGCTC"], include_rc=False, right_flank="CTC"
    )
    assert rf_oracle.feasible_any_gc is False
    with pytest.raises(RuntimeError):
        rf_opt.optimize("M", uniform_weights, right_flank="CTC")


def test_homodipeptide_tie_break_difference_between_last_codon_and_pathrank() -> None:
    """Pin the fuzzer-discovered permutation tie on `'FF'` (`TTT+TTC` vs `TTC+TTT`).

    Both `TTTTTC` and `TTCTTT` use one `TTT` and one `TTC` (exact same additive score
    and exact same GC = 1/6). `DPV2Optimizer` breaks intra-state ties on the LAST codon
    (`codon < existing_codon` -> `'TTC' < 'TTT'` -> selects `TTTTTC`), whereas full-prefix
    `PathRank` breaks ties on the FIRST differing codon (`['TTC', 'TTT'] < ['TTT', 'TTC']`
    -> selects `TTCTTT`). Both achieve the exact global maximum score.
    """
    weights = _make_varied_weights(seed=42)
    weights["TTT"] = 0.80
    weights["TTC"] = 0.50

    oracle = BruteForceCDSOracle.solve(
        "FF", weights, forbidden_motifs=[], target_gc_min=0.16, target_gc_max=0.17
    )
    assert set(oracle.best_sequences) == {"TTCTTT", "TTTTTC"}

    dp_res = DPV2Optimizer(forbidden_motifs=[]).optimize(
        "FF", weights, target_gc_min=0.16, target_gc_max=0.17
    )
    mirror = LeanExactMirrorDP([], scale=1_000_000)
    mirror_res = mirror.optimize_exact("FF", weights, target_gc_min=0.16, target_gc_max=0.17)
    assert mirror_res is not None
    assert dp_res["sequence"] == "TTTTTC"
    assert mirror_res.sequence == "TTCTTT"
    assert mirror.quantize_sequence_score(dp_res["sequence"], weights) == mirror_res.quantized_score


def _shrink_failing_instance(
    protein: str,
    motifs: list[str],
    failing_pred,
) -> tuple[str, list[str]]:
    """Minimal Hypothesis-style delta-debugging shrinker for property counterexamples."""
    cur_p = protein
    cur_m = list(motifs)
    changed = True
    while changed:
        changed = False
        if len(cur_p) > 1:
            for idx in range(len(cur_p)):
                cand_p = cur_p[:idx] + cur_p[idx + 1 :]
                if failing_pred(cand_p, cur_m):
                    cur_p = cand_p
                    changed = True
                    break
        if len(cur_m) > 1:
            for idx in range(len(cur_m)):
                cand_m = cur_m[:idx] + cur_m[idx + 1 :]
                if failing_pred(cur_p, cand_m):
                    cur_m = cand_m
                    changed = True
                    break
    return cur_p, cur_m


def test_seeded_property_fuzzer_200_instances_against_bruteforce_and_lean_mirror() -> None:
    """Run 200 randomized property instances cross-checking DPV2, BruteForce, and LeanMirror."""
    aa_alphabet = sorted(AA_TO_SENSE_CODONS.keys())
    bases = "ACGT"
    rng = random.Random(7112026)

    unique_optimum_exact_matches = 0
    margin_certified_score_matches = 0
    feasible_runs = 0

    for trial in range(200):
        length = rng.randint(1, 4)
        protein = "".join(rng.choice(aa_alphabet) for _ in range(length))
        num_motifs = rng.randint(1, 3)
        motifs = [
            "".join(rng.choice(bases) for _ in range(rng.randint(4, 6)))
            for _ in range(num_motifs)
        ]
        left_flank = "".join(rng.choice(bases) for _ in range(rng.randint(0, 4)))
        right_flank = "".join(rng.choice(bases) for _ in range(rng.randint(0, 4)))
        eff_motifs = expand_forbidden_motifs(motifs, include_rc=True)
        if has_any_substring_motif(left_flank, eff_motifs):
            left_flank = ""

        lo = round(rng.uniform(0.15, 0.55), 2)
        hi = round(rng.uniform(lo, min(0.90, lo + 0.35)), 2)
        weights = _make_varied_weights(seed=10_000 + trial)

        oracle = BruteForceCDSOracle.solve(
            protein=protein,
            codon_weights=weights,
            forbidden_motifs=motifs,
            include_rc=True,
            target_gc_min=lo,
            target_gc_max=hi,
            left_flank=left_flank,
            right_flank=right_flank,
        )
        opt = DPV2Optimizer(forbidden_motifs=motifs, include_reverse_complement=True)

        if not oracle.feasible_any_gc:
            with pytest.raises(RuntimeError):
                opt.optimize(
                    protein,
                    weights,
                    target_gc_min=lo,
                    target_gc_max=hi,
                    left_flank=left_flank,
                    right_flank=right_flank,
                )
            continue

        feasible_runs += 1
        res = opt.optimize(
            protein,
            weights,
            target_gc_min=lo,
            target_gc_max=hi,
            left_flank=left_flank,
            right_flank=right_flank,
        )

        def _check(
            p_test: str,
            m_test: list[str],
            w_cur: dict[str, float] = weights,
            lo_cur: float = lo,
            hi_cur: float = hi,
            lf_cur: str = left_flank,
            rf_cur: str = right_flank,
        ) -> bool:
            try:
                o_sub = BruteForceCDSOracle.solve(
                    p_test, w_cur, m_test, True, lo_cur, hi_cur, lf_cur, rf_cur
                )
                if not o_sub.feasible_any_gc:
                    return False
                r_sub = DPV2Optimizer(m_test, include_reverse_complement=True).optimize(
                    p_test, w_cur, lo_cur, hi_cur, lf_cur, rf_cur
                )
                return (
                    translate_dna(r_sub["sequence"]) != p_test
                    or r_sub["gc_feasible"] != o_sub.gc_feasible
                    or abs(r_sub["score"] - (o_sub.best_score or 0.0)) > 1e-10
                )
            except (RuntimeError, ValueError):
                return True

        if (
            translate_dna(res["sequence"]) != protein
            or res["gc_feasible"] != oracle.gc_feasible
            or abs(res["score"] - (oracle.best_score or 0.0)) > 1e-10
        ):
            shrunk_p, shrunk_m = _shrink_failing_instance(protein, motifs, _check)
            pytest.fail(
                f"Property failure on trial {trial} "
                f"(shrunk to protein={shrunk_p!r}, motifs={shrunk_m!r})"
            )

        assert not has_any_substring_motif(
            left_flank + res["sequence"] + right_flank, eff_motifs
        )
        assert res["sequence"] in oracle.best_sequences

        if oracle.gc_feasible and oracle.best_score is not None:
            mirror_engine = LeanExactMirrorDP(motifs, include_rc=True, scale=1_000_000)
            mirror = mirror_engine.optimize_exact(
                protein=protein,
                codon_weights=weights,
                target_gc_min=lo,
                target_gc_max=hi,
                left_flank=left_flank,
                right_flank=right_flank,
            )
            assert mirror is not None

            # Verify Prop_ApproxScoreExactness: when true float gap exceeds 2 * L * 1e-6,
            # Python float DP and quantized integer LeanMirror MUST achieve identical quantized optimum
            margin_rad = 2.0 * len(protein) * 1e-6
            if (
                oracle.second_best_score is None
                or (oracle.best_score - oracle.second_best_score) > margin_rad
            ):
                margin_certified_score_matches += 1
                dp_q_score = mirror_engine.quantize_sequence_score(res["sequence"], weights)
                assert dp_q_score == mirror.quantized_score

                # When the global argmax is unique (no permutation ties like FF: TTT+TTC vs TTC+TTT),
                # the sequence itself is byte-for-byte identical!
                if len(oracle.best_sequences) == 1:
                    unique_optimum_exact_matches += 1
                    assert res["sequence"] == mirror.sequence

    assert feasible_runs >= 150
    assert margin_certified_score_matches >= 100
    assert unique_optimum_exact_matches >= 80


def test_dpv230_and_dpv240_baseline_correspondence_and_documented_boundaries() -> None:
    """Verify baseline correspondence of DPV230/DPV240 and explicitly pin runtime boundaries."""
    weights = _make_varied_weights(seed=711)

    opt23 = DPV230Optimizer(
        forbidden_motifs=["GGTCTC"],
        include_reverse_complement=True,
        initiation_gc_min=0.0,
        initiation_gc_max=1.0,
        auto_annotate_pauses=False,
    )
    res23 = opt23.optimize("MAVL", weights, target_gc_min=0.35, target_gc_max=0.65)
    assert translate_dna(res23["sequence"]).rstrip("*") == "MAVL"
    assert "GGTCTC" not in res23["sequence"]
    assert "GAGACC" not in res23["sequence"]

    opt24_zero = DPV240Optimizer(
        forbidden_motifs=["GGTCTC"],
        include_reverse_complement=True,
        initiation_gc_min=0.0,
        initiation_gc_max=1.0,
        auto_annotate_pauses=False,
        pause_positions=[3],
        pause_penalty_weight=0.0,
    )
    opt24_base = DPV240Optimizer(
        forbidden_motifs=["GGTCTC"],
        include_reverse_complement=True,
        initiation_gc_min=0.0,
        initiation_gc_max=1.0,
        auto_annotate_pauses=False,
    )
    res24_zero = opt24_zero.optimize("MAVL", weights, target_gc_min=0.35, target_gc_max=0.65)
    res24_base = opt24_base.optimize("MAVL", weights, target_gc_min=0.35, target_gc_max=0.65)
    assert res24_zero["sequence"] == res24_base["sequence"]

    near_one = TASEPKineticsEngine.compute_smoothed_pause_map(
        "MAAAA",
        {5: [("TM", 3.0, 0.999)]},
        smoothing_window=3,
    )
    assert near_one[4][0][2] == 0.999
    assert near_one[3][0][2] == 1.0

    # 3a. Intra-state 1e-12 epsilon tie-break (`dp_v2.py:124`):
    #     For Serine ("S"), "TCT" (gc=1) and "AGT" (gc=1) collide in the SAME state `(1, 0)`.
    #     When their log-scores differ by 5e-13 (<= 1e-12), lexicographic tie-breaking
    #     (`"AGT" < "TCT"`) overrides the slightly higher float score of "TCT".
    eps_same_gc = {c: 0.05 for c, aa in STANDARD_GENETIC_CODE.items() if aa != "*"}
    eps_same_gc["TCT"] = math.exp(-0.5)
    eps_same_gc["AGT"] = math.exp(-0.5 - 5e-13)
    assert eps_same_gc["TCT"] > eps_same_gc["AGT"]
    res_intra = DPV2Optimizer(forbidden_motifs=[]).optimize(
        "S", eps_same_gc, target_gc_min=0.0, target_gc_max=1.0
    )
    assert res_intra["sequence"] == "AGT"

    # 3b. Cross-state exact float `max(...)` (`dp_v2.py:163`):
    #     For Phenylalanine ("F"), "TTT" (gc=0) and "TTC" (gc=1) occupy DIFFERENT GC states,
    #     so final selection uses exact float `max(...)` without 1e-12 tolerance -> picks "TTT".
    eps_diff_gc = dict(weights)
    eps_diff_gc["TTC"] = math.exp(-0.5 - 5e-13)
    eps_diff_gc["TTT"] = math.exp(-0.5)
    res_cross = DPV2Optimizer(forbidden_motifs=[]).optimize(
        "F", eps_diff_gc, target_gc_min=0.0, target_gc_max=1.0
    )
    assert res_cross["sequence"] == "TTT"
