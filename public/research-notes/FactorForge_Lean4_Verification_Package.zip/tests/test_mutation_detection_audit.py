"""Mutation-Testing Audit: verifies our oracle test assertions detect injected DP bugs (8/8 killed)."""

from __future__ import annotations

import math
from collections.abc import Callable

from factorforge.analysis.metrics import (
    STANDARD_GENETIC_CODE,
    translate_dna,
)

from .oracle_helpers import (
    AA_TO_SENSE_CODONS,
    BruteForceCDSOracle,
    compile_deterministic_automaton,
    expand_forbidden_motifs,
    has_any_substring_motif,
)


def _run_instrumented_dp(
    protein: str,
    codon_weights: dict[str, float],
    forbidden_motifs: list[str],
    target_gc_min: float,
    target_gc_max: float,
    left_flank: str,
    right_flank: str,
    mutant_id: str | None = None,
) -> dict[str, object]:
    """Reference copy of DPV2Optimizer with 8 selectable semantic bug injections."""
    include_rc = mutant_id != "M3_DROP_REVERSE_COMPLEMENT"
    auto = compile_deterministic_automaton(forbidden_motifs, include_rc=include_rc)

    s0 = 0
    if mutant_id != "M4_IGNORE_LEFT_FLANK":
        for ch in left_flank.upper():
            s0 = auto.step_nucleotide(s0, ch)
            if s0 in auto.terminal_states:
                raise ValueError("Left flank forbidden")

    n_codons = len(protein)
    total_nt = n_codons * 3
    min_gc = math.ceil(target_gc_min * total_nt)
    max_gc = math.floor(target_gc_max * total_nt)

    dp_layers: list[dict[tuple[int, int], tuple[float, str | None, int | None, int | None]]] = [
        {(0, s0): (0.0, None, None, None)}
    ]

    for aa in protein:
        codons = list(AA_TO_SENSE_CODONS[aa])
        if mutant_id == "M1_WRONG_SYNONYMOUS_CODON" and aa == "S":
            codons = ["AAA", *codons]  # Lysine codon injected into Serine menu

        cur_layer = dp_layers[-1]
        next_layer: dict[tuple[int, int], tuple[float, str | None, int | None, int | None]] = {}

        for (g, s), (score, _, _, _) in cur_layer.items():
            for codon in codons:
                next_s, is_forbidden = auto.step_codon(s, codon)
                if is_forbidden:
                    continue
                if mutant_id == "M2_GC_COUNT_DROP_C":
                    codon_gc = codon.count("G")
                else:
                    codon_gc = codon.count("G") + codon.count("C")

                log_w = math.log(max(codon_weights.get(codon, 1e-4), 1e-6))
                next_g = g + codon_gc
                next_sc = score + log_w
                key = (next_g, next_s)
                existing = next_layer.get(key)
                stored_prev_g = g + 1 if mutant_id == "M8_CORRUPT_BACKPOINTER" else g
                if existing is None:
                    next_layer[key] = (next_sc, codon, stored_prev_g, s)
                else:
                    ex_sc, _, _, _ = existing
                    better = (
                        next_sc < ex_sc - 1e-12
                        if mutant_id == "M7_MIN_INSTEAD_OF_MAX"
                        else next_sc > ex_sc + 1e-12
                    )
                    if better:
                        next_layer[key] = (next_sc, codon, stored_prev_g, s)
        if not next_layer:
            raise RuntimeError("Exhausted")
        dp_layers.append(next_layer)

    valid_finals = []
    for (g, s), val in dp_layers[-1].items():
        if mutant_id == "M5_IGNORE_RIGHT_FLANK":
            valid_finals.append(((g, s), val))
            continue
        curr = s
        ok = True
        for ch in right_flank.upper():
            curr = auto.step_nucleotide(curr, ch)
            if curr in auto.terminal_states:
                ok = False
                break
        if ok:
            valid_finals.append(((g, s), val))

    if mutant_id == "M6_OFF_BY_ONE_MAX_GC":
        in_band = [item for item in valid_finals if min_gc <= item[0][0] < max_gc]
    else:
        in_band = [item for item in valid_finals if min_gc <= item[0][0] <= max_gc]

    if not in_band:
        raise RuntimeError("No in-band candidate")
    best_item = max(in_band, key=lambda item: item[1][0])

    best_state, (best_score, _, _, _) = best_item
    chosen: list[str] = []
    cg, cs = best_state
    for idx in range(n_codons, 0, -1):
        _, codon, pg, ps = dp_layers[idx][(cg, cs)]
        assert codon is not None and pg is not None and ps is not None
        chosen.append(codon)
        cg, cs = pg, ps
    chosen.reverse()
    dna = "".join(chosen)
    return {"sequence": dna, "score": best_score}


def _oracle_contract_holds(mutant_id: str | None) -> bool:
    """Run our compact oracle battery against `mutant_id`; returns False iff mutant is KILLED."""
    weights = {c: 0.25 for c, aa in STANDARD_GENETIC_CODE.items() if aa != "*"}
    weights.update(
        {
            "AAA": 1.0,
            "TCT": 0.95,
            "AGC": 0.80,
            "ACC": 0.92,
            "ACA": 0.30,
            "GAC": 0.95,
            "GAT": 0.40,
            "CTG": 0.90,
            "TTA": 0.15,
            "GGT": 0.99,
            "GGA": 0.50,
        }
    )
    probes = [
        ("SL", ["GGTCTC"], 0.30, 0.67, "GGTC", "TAA"),
        ("TT", ["GGTCTC"], 0.66, 0.67, "", ""),
        ("DL", ["GGTCTC"], 0.33, 0.67, "GA", ""),
        ("G", ["GGTCTC"], 0.33, 1.0, "", "CTC"),
    ]

    try:
        for protein, motifs, lo, hi, lf, rf in probes:
            oracle = BruteForceCDSOracle.solve(
                protein=protein,
                codon_weights=weights,
                forbidden_motifs=motifs,
                include_rc=True,
                target_gc_min=lo,
                target_gc_max=hi,
                left_flank=lf,
                right_flank=rf,
            )
            res = _run_instrumented_dp(
                protein, weights, motifs, lo, hi, lf, rf, mutant_id=mutant_id
            )
            seq = str(res["sequence"])
            sc = float(res["score"])  # type: ignore[arg-type]
            eff = expand_forbidden_motifs(motifs, include_rc=True)
            if translate_dna(seq) != protein:
                return False
            if has_any_substring_motif(lf + seq + rf, eff):
                return False
            total_nt = len(protein) * 3
            gc_cnt = seq.count("G") + seq.count("C")
            if not (math.ceil(lo * total_nt) <= gc_cnt <= math.floor(hi * total_nt)):
                return False
            if oracle.best_score is None or abs(sc - oracle.best_score) > 1e-11:
                return False
            if seq not in oracle.best_sequences:
                return False
    except (AssertionError, KeyError, RuntimeError, ValueError):
        return False
    return True


def test_mutation_suite_kills_100_percent_of_injected_dp_bugs() -> None:
    """Baseline unmutated solver passes; all 8 injected semantic mutants are 100% KILLED."""
    assert _oracle_contract_holds(mutant_id=None) is True

    mutants: tuple[tuple[str, Callable[[], bool]], ...] = tuple(
        (m_id, lambda m=m_id: _oracle_contract_holds(m))
        for m_id in (
            "M1_WRONG_SYNONYMOUS_CODON",
            "M2_GC_COUNT_DROP_C",
            "M3_DROP_REVERSE_COMPLEMENT",
            "M4_IGNORE_LEFT_FLANK",
            "M5_IGNORE_RIGHT_FLANK",
            "M6_OFF_BY_ONE_MAX_GC",
            "M7_MIN_INSTEAD_OF_MAX",
            "M8_CORRUPT_BACKPOINTER",
        )
    )

    survived = [m_id for m_id, run_fn in mutants if run_fn()]
    assert survived == [], f"Mutants survived oracle detection: {survived}"
