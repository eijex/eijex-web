"""Regression checks for Job 712 portability and verifier trust inputs."""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("package_verifier", ROOT / "verify_all.py")
assert SPEC is not None and SPEC.loader is not None
verifier = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(verifier)


def test_lean_utf8_output_decoded_explicitly() -> None:
    result = verifier._run(
        [sys.executable, "-c", "import sys; sys.stdout.buffer.write(bytes([226,156,148]))"],
        ROOT, os.environ.copy(),
    )
    assert result.stdout == "\u2714"


def test_imports_use_hash_checked_snapshot() -> None:
    factorforge = __import__("factorforge")
    dp = __import__("factorforge.engines.dp_v2", fromlist=["DPV2Optimizer"])
    expected = ROOT / "factorforge_snapshot" / "src"
    assert Path(factorforge.__file__).is_relative_to(expected)
    assert Path(dp.__file__).is_relative_to(expected)


def test_package_runs_after_relocation(tmp_path: Path) -> None:
    relocated = tmp_path / "unrelated" / "package"
    shutil.copytree(ROOT, relocated, ignore=shutil.ignore_patterns(".lake", "__pycache__"))
    code = (
        "from tests import oracle_helpers; import factorforge; "
        "from pathlib import Path; import verify_all; "
        "assert Path(factorforge.__file__).is_relative_to(Path.cwd() / 'factorforge_snapshot'); "
        "verify_all._verify_reproducibility_manifest()"
    )
    proc = subprocess.run(
        [sys.executable, "-c", code], cwd=relocated,
        capture_output=True, text=True, encoding="utf-8", check=False,
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr


@pytest.mark.parametrize("relative", [
    "formal/FactorForgeFormal.lean", "formal/lake-manifest.json",
    "tests/conftest.py", "tests/test_verifier_regressions.py",
])
def test_manifest_cannot_omit_trust_inputs(monkeypatch, relative: str) -> None:
    data = json.loads((ROOT / "REPRODUCIBILITY_MANIFEST.json").read_text(encoding="utf-8-sig"))
    data["package_files_sha256"].pop(relative)
    monkeypatch.setattr(verifier.json, "loads", lambda _: data)
    with pytest.raises(SystemExit, match="Verification input inventory"):
        verifier._verify_reproducibility_manifest()
