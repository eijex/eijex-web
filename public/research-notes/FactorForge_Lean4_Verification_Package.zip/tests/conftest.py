"""Bind correspondence tests to the bundled, hash-checked Python source."""
import sys
from pathlib import Path

SOURCE_ROOT = Path(__file__).resolve().parents[1] / "factorforge_snapshot" / "src"
sys.path.insert(0, str(SOURCE_ROOT))
