"""FactorForge Lean 4 correspondence, brute-force oracle, and mutation test suite."""
