# FactorForge Lean 4 Formal Verification & Implementation Correspondence Package

Date: 2026-11-25  
Related Jobs: Job 710 (`710-lean4-dp-formal-verification`), Job 711 (`711-lean4-implementation-correspondence-and-packaging`)  
Epistemic Boundary: `UNVERIFIED_PUBLIC_CORPUS · Biological validation: NOT_AVAILABLE`

---

## Overview

This directory contains the standalone, fail-closed **Lean 4.36.0** formal verification and **Python implementation correspondence** package accompanying the Research Note `2026-11-25-lean4-formal-verification-of-factorforge-dp.md`.

Placing the verification suite here keeps the `factorforge` repository completely unmodified while providing a reproducible one-command verification bundle (`python verify_all.py`).

## Package Contents

- `formal/` — Standalone Lean 4 (`leanprover/lean4:v4.36.0`, Lake 5.0.0) package (`FactorForgeFormal`):
  - `spec_lock_manifest.json` — SHA-256 lock digests of all 6 specification files (`Spec/*.lean` and `Spec.lean`).
  - `FactorForgeFormal/Spec/` — Locked specifications (`Tropical.lean`, `Automaton.lean`, `GeneticCode.lean`, `ExactDP.lean`, `KineticAndParity.lean`).
  - `FactorForgeFormal/Proofs/` — 20 kernel-verified theorems (`0 sorry`, standard Lean axioms only).
  - `FactorForgeFormal/Witnesses.lean` — 14 non-vacuity witnesses and malformed-input refutations (`AAA` with fake `gc = 3`, stop-codon rejection, and constructive `"GGTC" + "SL" + "TAA"` backtracking).
  - `FactorForgeFormal/Audit.lean` — `#print axioms` verification across all 34 theorem and witness declarations.
- `tests/` — Fail-closed Python correspondence, brute-force oracle, property-based shrinking fuzzer, and mutation-testing kill suite:
  - `oracle_helpers.py` — Ground-truth `BruteForceCDSOracle` (raw substring checks, no Aho-Corasick) and exact integer `LeanExactMirrorDP`.
  - `test_formal_lean4_parity.py` — SHA-256 spec lock check, 64-for-64 Lean-vs-Python genetic code bijection check, banned cheat-token scan, witness parity, and fail-closed `lake build` + `leanchecker` test.
  - `test_bruteforce_and_correspondence.py` — Exhaustive boundary tests, 200-instance seeded shrinking property fuzzer, `FF` homodipeptide tie-break test (`last-codon` vs `PathRank`), and float/`round(..., 3)` boundary regression pins.
  - `test_mutation_detection_audit.py` — 8 injected DP bugs (`M1`–`M8`) with 100% (`8/8`) verified kill rate.
- `PROOF_COVERAGE_MATRIX.md` — Mapping of all 28 FactorForge mathematical formulations (`F1`–`F28`) to Lean theorems, Python functions, and verification tiers.
- `REPRODUCIBILITY_MANIFEST.json` — Exact `factorforge` commit, lockfile hashes, Lean toolchain version, and file SHA-256 digests.
- `verify_all.py` — Fail-closed one-command runner executing SHA-256 lock verification, `lake clean && lake build`, per-module `leanchecker`, `pytest -v`, `PYTHONHASHSEED=0..3` determinism, and `ruff check`.

## One-Command Verification

```powershell
python verify_all.py
```

## Job 712 review: exact proof boundary (2026-11-25)

The Lean kernel checks the declared discrete model. It does not prove a refinement theorem
from Python execution to Lean, and the Python mirror is another tested implementation,
not extracted Lean code. The 200 generated cases and 8 killed mutants describe this finite
suite; the mutants are injected into a reference copy, not production source mutations.

Three selection policies remain distinct: Lean `relaxCand` keeps the first enumerated
candidate on an exact score tie; the integer Python mirror uses full-prefix `PathRank`;
production DP uses last-codon comparison within a `1e-12` window and its own final-state
selection. `pathLexTotalOrder` proves an independent comparator's order laws. It does not
prove that `dpOptimize` returns the lexicographically smallest optimum. The constructive
Lean optimizer stores whole prefix paths; production reconstructs stored backpointers.
Score-optimal witness extraction is proved for the former, with the latter tested separately.

`Prop_ApproxScoreExactness` is a conditional perturbation theorem over lists of **Int**.
It assumes bounded errors; it does not establish a binary64 `math.log` error bound,
real logarithm semantics, quantizer scaling correctness, or the cumulative loss caused by
production epsilon-based relaxation. Consequently its `2 * L * eps` argument alone is
not a certificate for arbitrary production floating-point inputs. The fuzzer's margin
comparisons are observations on sampled inputs.

Optimality is relative to the supplied codon menus and additive integer scores.
`WellFormedMenu` establishes soundness, not completeness of all synonymous alternatives;
the `SL` witness demonstrates one menu, not universal menu completeness. Abstract DFA
safety assumes the supplied transition/terminal specification; no general Lean theorem
here proves that Python's compiler recognizes every arbitrary forbidden-substring set.
The C1 rows in the coverage matrix identify external suites, not suites executed by this
package. No biological mechanism or expression outcome follows from these proofs.

## Portable reproduction

Use Python 3.11 with pytest and ruff installed and the pinned Lean toolchain available
through elan. These external tools/dependencies are prerequisites, not bundled binaries.
`factorforge_snapshot/` contains the full source package plus its original pyproject and
lockfile, including initializers and registry data required for imports. Tests always load
this snapshot, not an installed FactorForge or a neighboring checkout. SHA-256 checks
bind all tracked snapshot files and every Lean/Python verification input, including the root
Lean import module and Lake manifest. Hashes establish integrity relative to this manifest,
not an independent authenticity guarantee or evidence of a clean Git commit.

Copy this entire directory to any path and run `python verify_all.py` there. Use the same
Python environment for reproduction; no installation of FactorForge itself is required.
The full verifier rebuilds Lean and runs pytest, four hash-seed checks and Ruff. The source
snapshot is research evidence and does not modify or release the production optimizer.
