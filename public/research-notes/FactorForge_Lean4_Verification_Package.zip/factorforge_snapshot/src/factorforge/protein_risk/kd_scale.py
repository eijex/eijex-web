"""Kyte-Doolittle scale and thresholds used by protein-risk heuristics."""

KD_SCALE = {
    "A": 1.8,
    "R": -4.5,
    "N": -3.5,
    "D": -3.5,
    "C": 2.5,
    "Q": -3.5,
    "E": -3.5,
    "G": -0.4,
    "H": -3.2,
    "I": 4.5,
    "L": 3.8,
    "K": -3.9,
    "M": 1.9,
    "F": 2.8,
    "P": -1.6,
    "S": -0.8,
    "T": -0.7,
    "W": -0.9,
    "Y": -1.3,
    "V": 4.2,
}

TM_WINDOW = 19
TM_THRESHOLD = 1.6
MEAN_KD_RISK_THRESHOLD = 0.3
SP_HRUN_MIN = 7
SP_SCAN_WINDOW = 30
