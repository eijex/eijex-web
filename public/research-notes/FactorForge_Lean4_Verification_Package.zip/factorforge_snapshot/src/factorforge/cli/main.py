"""
FactorForge CLI

Usage:
  factorforge optimize input.fasta -e profile -p balanced -o output.fasta
  factorforge optimize input.fasta -e profile -p balanced --template standard_expression -o output.gb --format genbank
  factorforge list-engines
"""

import hashlib
import json
import sys
from pathlib import Path

import click

from factorforge import __version__
from factorforge.analysis.feasibility import DEFAULT_CAI_TARGET
from factorforge.cli.structure_cli import structure_cli
from factorforge.cli.updater import check_factorforge_update, format_update_report
from factorforge.engines import register_builtin_engines
from factorforge.engines.profile.utils import parse_fasta_records
from factorforge.engines.registry import EngineRegistry
from factorforge.nbfold.cli import nbfold_cli

register_builtin_engines()

HOST_MAP = {"nbenthamiana": "nbenthamiana", "by2": "ntabacum"}
HOST_TAXIDS = {"nbenthamiana": 4100, "ntabacum": 4097}
PACKAGE_ROOT = Path(__file__).resolve().parents[1]
FACTORFORGE_REPO_ROOT = Path(__file__).resolve().parents[3]
REFERENCE_POLICY_MANIFEST_PATH = (
    FACTORFORGE_REPO_ROOT / "data" / "reference" / "reference_policy_manifest.json"
)
BUNDLED_REFERENCE_POLICY_MANIFEST_PATH = (
    PACKAGE_ROOT / "data" / "reference" / "reference_policy_manifest.json"
)


def _reference_policy_manifest_path() -> Path:
    """Return the repo manifest during development, or the packaged manifest in wheels."""
    if REFERENCE_POLICY_MANIFEST_PATH.exists():
        return REFERENCE_POLICY_MANIFEST_PATH
    return BUNDLED_REFERENCE_POLICY_MANIFEST_PATH


def _resolve_packaged_or_repo_path(relative_path: str) -> Path:
    """Resolve manifest paths in a source checkout or an installed wheel."""
    repo_path = FACTORFORGE_REPO_ROOT / relative_path
    if repo_path.exists():
        return repo_path

    package_prefix = "src/factorforge/"
    if relative_path.startswith(package_prefix):
        return PACKAGE_ROOT / relative_path.removeprefix(package_prefix)
    return PACKAGE_ROOT / relative_path


def _load_reference_policy_manifest() -> dict:
    """Load the checksum/tier policy manifest for expert CLI reference selection."""
    return json.loads(_reference_policy_manifest_path().read_text(encoding="utf-8"))


def _reference_entries_by_id() -> dict[str, dict]:
    manifest = _load_reference_policy_manifest()
    return {entry["reference_id"]: entry for entry in manifest["references"]}


def _reference_id_choices() -> tuple[str, ...]:
    return tuple(_reference_entries_by_id())


REFERENCE_ID_CHOICES = _reference_id_choices()


def _reference_entry_by_id(reference_id: str) -> dict:
    entries = _reference_entries_by_id()
    try:
        return entries[reference_id]
    except KeyError as exc:
        choices = ", ".join(sorted(entries))
        raise click.UsageError(
            f"Unknown reference_id {reference_id!r}. Supported values: {choices}"
        ) from exc


def _sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resolve_reference_by_id(reference_id: str) -> Path:
    """Resolve a manifest reference_id to a checksum-verified codon table path."""
    entry = _reference_entry_by_id(reference_id)
    codon_table_path = _resolve_packaged_or_repo_path(str(entry["codon_table_path"]))
    expected = str(entry["checksum_sha256"])
    if not codon_table_path.exists():
        raise click.UsageError(
            f"Codon table file for {reference_id} does not exist: {codon_table_path}"
        )
    actual = _sha256_file(codon_table_path)
    if actual != expected:
        raise click.UsageError(
            "Checksum mismatch for "
            f"{reference_id} at {codon_table_path}: expected {expected}, actual {actual}"
        )

    if entry["tier"] != "production_enabled":
        limitations = "; ".join(entry.get("known_limitations", []))
        warning = (
            f"Warning: reference_id={reference_id} has tier={entry['tier']}; "
            f"{entry['claim_boundary']}"
        )
        if limitations:
            warning = f"{warning} Known limitations: {limitations}"
        click.echo(warning, err=True)

    return codon_table_path


def _validate_reference_host(reference_id: str, internal_host: str) -> None:
    entry = _reference_entry_by_id(reference_id)
    expected_taxid = HOST_TAXIDS[internal_host]
    actual_taxid = int(entry["ncbi_taxid"])
    if actual_taxid != expected_taxid:
        raise click.UsageError(
            f"reference_id={reference_id} targets {entry['organism']} "
            f"(NCBI taxid {actual_taxid}) and is incompatible with "
            f"--host {internal_host} (expected NCBI taxid {expected_taxid})."
        )


def _configure_stdio() -> None:
    """Best-effort UTF-8 for Windows consoles."""
    for stream in (sys.stdout, sys.stderr):
        try:
            reconfigure = getattr(stream, "reconfigure", None)
            if callable(reconfigure):
                reconfigure(encoding="utf-8")
        except Exception:
            pass


def _parse_csv_option(value):
    """Parse comma-separated option values."""
    if not value:
        return None
    parsed = [item.strip() for item in value.split(",") if item.strip()]
    return parsed or None


def _wrap_sequence(sequence, width=80):
    """Wrap sequence to fixed-width lines."""
    return "\n".join(sequence[i : i + width] for i in range(0, len(sequence), width))


def _build_dp_result(
    sequence: str,
    objective: str,
    gc_min: float,
    gc_max: float,
    cai_target: float = DEFAULT_CAI_TARGET,
    codon_table_path: Path | None = None,
    codon_reference_id: str | None = None,
    pause_positions: list[int] | None = None,
):
    """Run the constraint-based DP feasibility engine for a single protein sequence."""
    if objective != "feasibility_best":
        raise ValueError("DP engine currently supports --objective feasibility_best.")
    if gc_min > gc_max:
        raise ValueError("--gc-min must be <= --gc-max.")

    from factorforge.analysis.metrics import load_codon_usage_table

    table = load_codon_usage_table(path=codon_table_path)
    if pause_positions:
        from factorforge.engines.dp_v2_4 import DPV240Optimizer

        if not 0 <= gc_min <= gc_max <= 100:
            raise ValueError("4DP GC bounds must be percentages between 0 and 100.")
        dp_optimizer = DPV240Optimizer(
            pause_positions=pause_positions,
            pause_target_adaptiveness=0.35,
            pause_penalty_weight=3.5,
            enable_tasep_smoothing=True,
            tasep_smoothing_window=3,
        )
        dp_result = dp_optimizer.optimize(
            protein_sequence=sequence,
            codon_weights=table.codon_weights,
            target_gc_min=gc_min / 100.0,
            target_gc_max=gc_max / 100.0,
        )
        engine_name = "dp_v2_4"
    else:
        from factorforge.engines.dp_v2 import DPV2Optimizer

        dp_result = DPV2Optimizer().optimize(
            protein_sequence=sequence,
            codon_weights=table.codon_weights,
            target_gc_min=gc_min,
            target_gc_max=gc_max,
        )
        engine_name = "dp_v2"

    best = {
        "dna_sequence": dp_result["sequence"],
        "cai": dp_result.get("cai", dp_result.get("cai_global", 0.0)),
        "gc": dp_result.get("gc_percent", dp_result.get("gc", 0.0)),
    }
    feasible = bool(dp_result.get("gc_feasible", dp_result.get("is_gc_feasible", True)))
    result = {
        "target": {
            "gc_low": gc_min,
            "gc_high": gc_max,
            "cai": cai_target,
            "best_candidate": best if feasible else None,
        },
        "engine": engine_name,
        "codon_reference_id": codon_reference_id,
        "pause_positions": pause_positions,
    }

    reason = (
        f"Maximum CAI under GC {gc_min:g}-{gc_max:g}%"
        if feasible
        else "Closest reachable GC band candidate; requested GC range was infeasible"
    )
    if pause_positions:
        reason = f"4DP score with {len(pause_positions)} model offset hypotheses under the requested constraints"
    return best, result, reason


def _format_dp_fasta(
    sequence_id: str,
    dna_sequence: str,
    cai: float,
    gc: float,
    requested_cai_target: float | None = None,
    pause_positions: list[int] | None = None,
) -> str:
    """Format a DP result as FASTA."""
    engine_tag = "dp_4dp" if pause_positions else "dp"
    header = f">{sequence_id}|engine={engine_tag}|objective=feasibility_best|cai={cai:.3f}|gc={gc:.2f}"
    if pause_positions:
        pauses_str = ",".join(str(p) for p in pause_positions)
        header = f"{header}|pauses={pauses_str}"
    if requested_cai_target is not None:
        header = f"{header}|target_cai={requested_cai_target:.3f}"
    return f"{header}\n{_wrap_sequence(dna_sequence)}\n"


def _option_was_explicitly_set(option_name: str) -> bool:
    """Return whether an option was provided on the command line."""
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return False
    get_parameter_source = getattr(ctx, "get_parameter_source", None)
    if not callable(get_parameter_source):
        return False
    return get_parameter_source(option_name) == click.core.ParameterSource.COMMANDLINE


def _engine_option_was_explicitly_set() -> bool:
    """Return whether --engine/-e was provided on the command line."""
    return _option_was_explicitly_set("engine")


def _format_profile_fasta(sequence_id: str, profile: str, result) -> str:
    """Format a profile optimization result as FASTA."""
    cai = float(result.metrics.get("cai", 0.0))
    gc = float(result.metrics.get("gc_percent", result.metrics.get("gc_content", 0.0)))
    score = float(result.metrics.get("score", 0.0))
    header = (
        f">{sequence_id}|engine=profile|profile={profile}|"
        f"cai={cai:.3f}|gc={gc:.2f}|score={score:.3f}"
    )
    return f"{header}\n{_wrap_sequence(result.sequence)}\n"


def _single_profile_sequence_id(input_file: str, fasta_records) -> str:
    if fasta_records is not None and len(fasta_records) == 1:
        return str(fasta_records[0][0])
    return Path(input_file).stem or "factorforge_profile"


def _format_profile_comparison_table(profile_results) -> str:
    """Format profile optimization metrics as a comparison table."""
    divider = "─" * 45
    lines = [
        "Profile comparison results:",
        divider,
        f"{'Profile':<18}{'CAI':>7} {'GC%':>7} {'Score':>8}",
        divider,
    ]
    for profile_name, result in profile_results:
        cai = float(result.metrics.get("cai", 0.0))
        gc = float(result.metrics.get("gc_percent", result.metrics.get("gc_content", 0.0)))
        score = float(result.metrics.get("score", 0.0))
        lines.append(f"{profile_name:<18}{cai:>7.3f} {gc:>7.2f} {score:>8.3f}")
    lines.append(divider)
    return "\n".join(lines)


@click.group()
@click.version_option(version=__version__)
def cli():
    """FactorForge - Codon Optimization Platform"""
    _configure_stdio()


@cli.command()
def list_engines():
    """List available optimization engines"""
    engines = EngineRegistry.list_engines()

    click.echo("\nAvailable Engines:\n")
    for name, info in engines.items():
        click.echo(f"  - {name}: {info['name']} v{info['version']}")
    click.echo()


@cli.command()
@click.argument("input_file", type=click.Path(exists=True))
@click.option(
    "--engine",
    "-e",
    default="dp",
    type=click.Choice(["dp", "profile", "lm", "slm"], case_sensitive=False),
    help="Engine (dp, profile, lm, slm)",
)
@click.option(
    "--host",
    default="nbenthamiana",
    type=click.Choice(["nbenthamiana", "by2"], case_sensitive=False),
    help="Expression host: nbenthamiana (default) or by2 (Tobacco BY-2 / N. tabacum)",
)
@click.option("--profile", "-p", default="balanced", help="Optimization profile")
@click.option(
    "--objective",
    default="feasibility_best",
    type=click.Choice(["feasibility_best"], case_sensitive=False),
    help="DP objective",
)
@click.option("--gc-min", type=float, default=40.0, help="Minimum target GC percentage")
@click.option("--gc-max", type=float, default=47.0, help="Maximum target GC percentage")
@click.option(
    "--cai-target",
    type=float,
    default=DEFAULT_CAI_TARGET,
    help="Requested DP target CAI threshold",
)
@click.option("--template", "construct_template", help="Construct template name")
@click.option("--output", "-o", help="Output file")
@click.option("--format", "output_format", default="fasta", help="Output format (fasta, genbank)")
@click.option(
    "--reference-id",
    type=click.Choice(REFERENCE_ID_CHOICES, case_sensitive=False),
    default=None,
    help="Expert/research codon-reference ID; checksum-validated.",
)
@click.option(
    "--compare-profiles",
    help=(
        "Comma-separated profiles to compare "
        "(e.g. balanced,high_cai,gc_target). Implies --engine profile."
    ),
)
@click.option(
    "--scan-mode",
    default="full",
    type=click.Choice(["full", "fast"], case_sensitive=False),
    help="Rule scan mode",
)
@click.option("--scan-include", help="Comma-separated scanner names to include")
@click.option("--scan-exclude", help="Comma-separated scanner names to exclude")
@click.option("--save-db/--no-save-db", default=False, help="Save optimization result to PostgreSQL DB")
@click.option(
    "--pause-sidecar",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Local ingest-af3 JSON for experimental 4DP. Requires one complete chain matching the input protein.",
)
@click.option(
    "--allow-mock",
    is_flag=True,
    default=False,
    help="Allow synthetic/mock structure sidecars for testing. Blocked by default.",
)
def optimize(
    input_file,
    engine,
    host,
    profile,
    objective,
    gc_min,
    gc_max,
    cai_target,
    construct_template,
    output,
    output_format,
    reference_id,
    compare_profiles,
    scan_mode,
    scan_include,
    scan_exclude,
    save_db,
    pause_sidecar,
    allow_mock=False,
):
    """Optimize protein sequence"""
    compare_profile_list = _parse_csv_option(compare_profiles)
    engine = engine.lower()
    host_value = host.lower()
    internal_host = HOST_MAP[host_value]
    host_was_explicit = _option_was_explicitly_set("host")
    reference_id = reference_id.lower() if reference_id else None
    reference_table_path = None

    if reference_id is not None:
        _validate_reference_host(reference_id, internal_host)
        reference_table_path = resolve_reference_by_id(reference_id)

    if host_was_explicit and engine == "dp" and _engine_option_was_explicitly_set():
        raise click.UsageError("--host is only supported with --engine profile")
    if host_was_explicit and engine == "dp" and internal_host != "nbenthamiana":
        engine = "profile"

    if host_was_explicit and internal_host != "nbenthamiana":
        if profile == "high_cai" or "high_cai" in (compare_profile_list or []):
            raise click.UsageError(
                "high_cai requires the N. benthamiana golden-set reference "
                "and is not available for non-default hosts."
            )

    if compare_profile_list:
        if engine == "dp" and _engine_option_was_explicitly_set():
            raise click.UsageError("--compare-profiles cannot be used with --engine dp.")
        engine = "profile"

    if reference_table_path is not None and construct_template:
        raise click.UsageError("--reference-id is not supported with --template mode.")

    if pause_sidecar is not None and engine != "dp":
        raise click.UsageError("--pause-sidecar is only supported with --engine dp.")

    try:
        # Read file
        with open(input_file, encoding="utf-8") as f:
            raw_input = f.read()

        scan_include_list = _parse_csv_option(scan_include)
        scan_exclude_list = _parse_csv_option(scan_exclude)

        fasta_records = None
        sequence = raw_input.strip()
        if raw_input.lstrip().startswith(">"):
            fasta_records = parse_fasta_records(raw_input)
            if len(fasta_records) == 1:
                sequence = fasta_records[0][1]

        if compare_profile_list:
            if fasta_records is not None and len(fasta_records) > 1:
                raise ValueError("Profile comparison requires a single input sequence.")
            if construct_template:
                raise ValueError("Profile comparison does not support --template mode.")
            if output_format.lower() != "fasta":
                raise ValueError("Profile comparison only supports FASTA output.")

            if reference_table_path is not None:
                from factorforge.engines.profile.optimizer import RuleBasedOptimizer

                optimizer = RuleBasedOptimizer(
                    codon_table_path=str(reference_table_path),
                    generation_reference_id=reference_id,
                )
            else:
                optimizer = EngineRegistry.get("profile")
            profile_results = []
            for profile_name in compare_profile_list:
                result = optimizer.optimize(
                    sequence,
                    profile=profile_name,
                    host=internal_host,
                    scan_mode=scan_mode,
                    scan_include=scan_include_list,
                    scan_exclude=scan_exclude_list,
                )
                profile_results.append((profile_name, result))

            if output:
                first_profile, first_result = profile_results[0]
                sequence_id = Path(input_file).stem or "factorforge_profile"
                fasta = _format_profile_fasta(sequence_id, first_profile, first_result)
                with open(output, "w", encoding="utf-8") as f:
                    f.write(fasta)
                click.echo(f"Saved to: {output}")

            click.echo(_format_profile_comparison_table(profile_results))
            return

        if fasta_records is not None and len(fasta_records) > 1:
            if engine == "dp":
                raise ValueError("Multi-FASTA input requires --engine profile.")
            if construct_template:
                raise ValueError("Multi-FASTA input does not support --template mode.")
            if output_format.lower() != "fasta":
                raise ValueError("Multi-FASTA input only supports FASTA output.")

            if reference_table_path is not None and engine == "profile":
                from factorforge.engines.profile.optimizer import RuleBasedOptimizer

                optimizer = RuleBasedOptimizer(
                    codon_table_path=str(reference_table_path),
                    generation_reference_id=reference_id,
                )
            else:
                optimizer = EngineRegistry.get(engine)
            payload = [{"id": seq_id, "sequence": seq} for seq_id, seq in fasta_records]
            if hasattr(optimizer, "optimize_batch"):
                results = optimizer.optimize_batch(
                    payload,
                    profile=profile,
                    host=internal_host,
                    scan_mode=scan_mode,
                    scan_include=scan_include_list,
                    scan_exclude=scan_exclude_list,
                )
            else:
                results = [
                    optimizer.optimize(
                        seq,
                        profile=profile,
                        host=internal_host,
                        scan_mode=scan_mode,
                        scan_include=scan_include_list,
                        scan_exclude=scan_exclude_list,
                    )
                    for _id, seq in fasta_records
                ]

            combined_fasta = []
            for idx, result in enumerate(results):
                seq_id = payload[idx]["id"]
                combined_fasta.append(
                    _format_profile_fasta(seq_id, profile, result).rstrip()
                )
            out_content = "\n".join(combined_fasta) + "\n"

            if output:
                with open(output, "w", encoding="utf-8") as f:
                    f.write(out_content)
                click.echo(f"Saved batch FASTA to: {output}")
            else:
                click.echo(f"\n{out_content}")
            click.echo(f"Batch optimized: {len(results)} sequences")
            return

        pause_positions = None
        if pause_sidecar is not None:
            from factorforge.structure.alphafold_server_ingest import (
                extract_pause_positions_from_sidecar,
            )
            pause_positions = extract_pause_positions_from_sidecar(
                pause_sidecar, sequence, allow_mock=allow_mock
            )
            click.echo(f"Loaded {len(pause_positions)} sequence-matched model offset positions: {pause_positions}")

        if engine == "dp":
            if construct_template:
                raise ValueError("DP engine does not support --template mode.")
            if output_format.lower() != "fasta":
                raise ValueError("DP engine only supports FASTA output.")

            best, feasibility, recommendation_reason = _build_dp_result(
                sequence,
                objective=objective,
                gc_min=gc_min,
                gc_max=gc_max,
                cai_target=cai_target,
                codon_table_path=reference_table_path,
                codon_reference_id=reference_id,
                pause_positions=pause_positions,
            )
            dna_sequence = best["dna_sequence"]
            cai = float(best["cai"])
            gc = float(best["gc"])
            sequence_id = Path(input_file).stem or "factorforge_dp"
            requested_cai_target = cai_target if _option_was_explicitly_set("cai_target") else None
            fasta = _format_dp_fasta(
                sequence_id,
                dna_sequence,
                cai,
                gc,
                requested_cai_target=requested_cai_target,
                pause_positions=pause_positions,
            )

            if pause_positions:
                click.echo("Optimizing with experimental DP v2.4 model offsets...")
            else:
                click.echo("Optimizing with DP v2 exact constraint engine...")
            if output:
                with open(output, "x" if pause_sidecar is not None else "w", encoding="utf-8") as f:
                    f.write(fasta)
                click.echo(f"Saved to: {output}")
            else:
                click.echo(f"\n{fasta}")

            click.echo("Metrics:")
            click.echo(f"  - cai: {cai:.3f}")
            click.echo(f"  - gc_percent: {gc:.2f}")
            click.echo(f"  - target_gc_min: {float(feasibility['target']['gc_low']):.2f}")
            click.echo(f"  - target_gc_max: {float(feasibility['target']['gc_high']):.2f}")
            if requested_cai_target is not None:
                click.echo(f"  - target_cai: {float(feasibility['target']['cai']):.3f}")
            click.echo(f"  - target_feasible: {bool(feasibility['target']['best_candidate'])}")
            if pause_positions:
                click.echo(f"  - cotranslational_pauses: {pause_positions}")
            click.echo(f"  - recommendation_reason: {recommendation_reason}")
            return

        if engine == "profile" and construct_template:
            from factorforge.engines.profile.pipeline import OptimizationPipeline

            pipeline = OptimizationPipeline(
                profile=profile,
                construct_template=construct_template,
                host=internal_host,
            )
            result = pipeline.run(
                sequence,
                host=internal_host,
                scan_mode=scan_mode,
                scan_include=scan_include_list,
                scan_exclude=scan_exclude_list,
            )

            if output_format.lower() == "genbank" and not output:
                raise ValueError("GenBank output requires --output file path.")

            if output:
                result.save(Path(output), format=output_format)
                click.echo(f"Saved to: {output}")
            else:
                click.echo(f"\n{result.sequence}\n")

            click.echo("Metrics:")
            for key, value in result.metadata.get("metrics", {}).items():
                click.echo(f"  - {key}: {value}")
        else:
            if output_format.lower() != "fasta":
                raise ValueError("Non-FASTA output requires --template with profile pipeline.")

            # Get engine
            if reference_table_path is not None and engine == "profile":
                from factorforge.engines.profile.optimizer import RuleBasedOptimizer

                optimizer = RuleBasedOptimizer(
                    codon_table_path=str(reference_table_path),
                    generation_reference_id=reference_id,
                )
            else:
                optimizer = EngineRegistry.get(engine)

            # Optimize
            click.echo(f"Optimizing with {optimizer.name} v{optimizer.version}...")
            result = optimizer.optimize(
                sequence,
                profile=profile,
                host=internal_host,
                scan_mode=scan_mode,
                scan_include=scan_include_list,
                scan_exclude=scan_exclude_list,
            )

            # Output results
            if output:
                sequence_id = _single_profile_sequence_id(input_file, fasta_records)
                fasta = _format_profile_fasta(sequence_id, profile, result)
                with open(output, "w", encoding="utf-8") as f:
                    f.write(fasta)
                click.echo(f"Saved to: {output}")
            else:
                click.echo(f"\n{result.sequence}\n")

            # Output metrics
            click.echo("Metrics:")
            for key, value in result.metrics.items():
                click.echo(f"  - {key}: {value}")
                
            if save_db:
                from factorforge.db.connector import FactorForgeDBConnector
                
                click.echo("Saving to PostgreSQL Database...")
                connector = FactorForgeDBConnector()
                
                run_metadata = {
                    "execution_origin": "standalone_cli",
                    "actual_engine_name": optimizer.name,
                    "actual_profile_name": profile,
                    "actual_engine_objective": objective if engine == "dp" else None,
                    "generation_performed": True,
                    "analysis_mode": scan_mode,
                    "evidence_level": "prospective_factorforge",
                    "runner_entrypoint": "factorforge.cli.main"
                }

                candidate_data = {
                    "optimized_sequence": result.sequence,
                    "cai": result.metrics.get("cai", None),
                    "gc_percent": result.metrics.get("gc_content", None),
                    "computational_status": "passed" if not result.metrics.get("violations", 0) else "rejected"
                }
                
                check_results = []
                # Map metrics to Configured Constraints where applicable
                if "gc_target_reached" in result.metrics:
                    check_results.append({
                        "check_domain": "configured_constraint",
                        "result": "PASS" if result.metrics["gc_target_reached"] else "FAIL",
                        "observed_value": result.metrics.get("gc_percent"),
                        "details_json": {"rule": "GC Target", "min": gc_min, "max": gc_max}
                    })

                # Map warnings to Advisory / Assembly Review / Sequence Integrity
                for scan_warn in result.metadata.get("scan_warnings", []):
                    rule_name = scan_warn.get("rule_name", "UNKNOWN").lower()
                    if "bsai" in rule_name or "bsmbi" in rule_name or "type iis" in rule_name:
                        domain = "assembly_review"
                    elif "stop" in rule_name or "frame" in rule_name:
                        domain = "sequence_integrity"
                    else:
                        domain = "advisory_sequence_risk"
                        
                    check_results.append({
                        "check_domain": domain,
                        "result": "WARN",
                        "observed_value": None,
                        "details_json": scan_warn
                    })
                
                if not check_results:
                    check_results.append({
                        "check_domain": "advisory_sequence_risk",
                        "result": "PASS",
                        "observed_value": 1.0,
                        "details_json": {"message": "All default scans passed cleanly."}
                    })
                
                try:
                    run_id = connector.save_computational_provenance(
                        run_metadata=run_metadata,
                        candidate_data=candidate_data,
                        check_results=check_results
                    )
                    click.echo(f"Successfully recorded execution provenance (Run ID: {run_id})")
                except Exception as db_e:
                    click.echo("Optimization completed, but DB persistence failed. No database records were committed.", err=True)
                    click.echo(f"DB Error Details: {db_e}", err=True)
                    raise click.Abort()

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()

@cli.command()
@click.option("--model-id", required=True, help="UUID of the model version in ml.model_registry")
@click.option("--train-snapshot", required=True, help="UUID of the training dataset snapshot")
@click.option("--eval-snapshot", required=True, help="UUID of the evaluation dataset snapshot")
@click.option("--input-sequence", required=True, help="Generated sequence to audit")
def evaluate_model(model_id, train_snapshot, eval_snapshot, input_sequence):
    """
    Evaluates ML evaluation integrity (Dataset Leakage and Generation Memorization).
    """
    click.echo(f"Evaluating Model Integrity for {model_id}...")
    
    # 1. We would resolve snapshots from DB here. Mocking for MVP:
    click.echo(f"Resolving snapshots: Train={train_snapshot}, Eval={eval_snapshot}")
    mock_train_seqs = ["ATGGCTAAATGGTAA", "ATGCGTACGTGCTAG"]
    mock_eval_seqs = ["ATGCCCGGGAAATTT"]
    
    from factorforge.review.evaluation_integrity import (
        DatasetLeakageAuditor,
        GenerationMemorizationAuditor,
    )
    
    # 2. Dataset Leakage Audit
    ds_auditor = DatasetLeakageAuditor(mock_train_seqs, mock_eval_seqs)
    ds_check_exact = ds_auditor.audit_exact_overlap()
    ds_check_homology = ds_auditor.audit_homology_overlap()
    
    # 3. Generation Memorization Audit
    mem_auditor = GenerationMemorizationAuditor(mock_train_seqs)
    mem_check_exact = mem_auditor.audit_exact_match(input_sequence)
    mem_check_homology = mem_auditor.audit_high_similarity(input_sequence)
    
    all_checks = [ds_check_exact, ds_check_homology, mem_check_exact, mem_check_homology]
    
    for chk in all_checks:
        click.echo(f"[{chk['result']}] {chk['check_type']}: {chk['details_json']['message']}")
        
    try:
        from factorforge.db.connector import FactorForgeDBConnector
        connector = FactorForgeDBConnector()
        run_data = {
            "model_id": model_id,
            "evaluation_snapshot_id": eval_snapshot,
            "engine_name": "FactorForgeLM",
            "evaluation_protocol": "benchmark_leakage_audit",
            "status": "completed"
        }
        run_id = connector.save_ml_evaluation_provenance(run_data, all_checks)
        click.echo(f"\nSuccessfully recorded ML Evaluation Provenance (Run ID: {run_id})")
    except Exception as db_e:
        click.echo("Evaluation completed, but DB persistence failed.", err=True)
        click.echo(f"DB Error Details: {db_e}", err=True)

@cli.command()
@click.argument("input_file", type=click.Path(exists=True), required=False)
@click.option("--sequence", "-s", help="Raw protein amino acid sequence string")
@click.option("--target-name", default="Target-Protein", help="Human-readable target construct name")
@click.option("--top-k", "-k", default=3, type=int, help="Number of Top-K candidate designs to return (1-10)")
@click.option("--host", default="nbenthamiana", type=click.Choice(["nbenthamiana", "by2"]), help="Host organism")
@click.option("--novelty-class", default="Class_A_InDistribution", help="Novelty stratification class")
@click.option("--output", "-o", type=click.Path(), help="Output path for JSON Candidate Slate")
@click.option("--json-output", is_flag=True, help="Print raw JSON to stdout")
def slate(
    input_file,
    sequence,
    target_name,
    top_k,
    host,
    novelty_class,
    output,
    json_output,
):
    """
    Run multi-contract discovery to produce a diverse, Pareto-filtered Top-K candidate slate.
    """
    _configure_stdio()
    if input_file:
        fasta_records = parse_fasta_records(input_file)
        if not fasta_records:
            raise click.UsageError(f"No FASTA records found in {input_file}")
        target_name = fasta_records[0].header or target_name
        target_aa = fasta_records[0].sequence
    elif sequence:
        target_aa = sequence
    else:
        raise click.UsageError("Either INPUT_FILE or --sequence must be provided.")

    from factorforge.discovery.slate import DiscoverySlateEngine

    engine = DiscoverySlateEngine(host=HOST_MAP.get(host, "nbenthamiana"))
    candidate_slate = engine.generate_slate(
        target_aa=target_aa,
        target_name=target_name,
        novelty_class=novelty_class,
        top_k=top_k,
    )

    data = candidate_slate.to_dict()
    if output:
        with open(output, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        click.echo(f"Candidate slate saved to: {output}")
    elif json_output:
        click.echo(json.dumps(data, indent=2))
    else:
        click.echo("\n=======================================================")
        click.echo(f"FactorForge Discovery Slate: {candidate_slate.target_metadata.target_name}")
        click.echo(f"Run ID: {candidate_slate.run_id}")
        click.echo(f"Top-K Candidates: {candidate_slate.slate_summary.top_k_count} / Feasible: {candidate_slate.slate_summary.feasible_pool_size}")
        click.echo(f"Diversity Index: {candidate_slate.slate_summary.diversity_index:.4f}")
        click.echo("=======================================================\n")
        for cand in candidate_slate.candidates:
            click.echo(f"[{cand.rank}] {cand.strategy_cluster} (Utility: {cand.utility_score:.3f})")
            click.echo(f"    Contract: {cand.generation_contract}")
            click.echo(f"    CAI: {cand.trait_vector.cai_golden_set:.3f} | GC: {cand.trait_vector.global_gc_percent:.1f}% | 5' MFE: {cand.trait_vector.initiation_mfe_kcal_mol} kcal/mol")
            click.echo(f"    Digest: {cand.sequence_digest}")
            click.echo(f"    Rationale: {cand.rationale}\n")


@cli.command("acquisition-panel")
@click.option("--output-dir", "-o", default="benchmarks/results/prospective_panel_v3.5", help="Output directory for prospective panel package")
@click.option("--replicates", "-r", default=3, type=int, help="Biological replicates per construct")
@click.option("--seed", "-s", default=42, type=int, help="Randomization seed for blinded plate assignment")
@click.option("--experiment-id", default="EXP-20260917-PILOT-01", help="Experimental run identifier")
@click.option("--host", default="nbenthamiana", type=click.Choice(["nbenthamiana", "by2"]), help="Host organism")
def acquisition_panel(output_dir, replicates, seed, experiment_id, host):
    """
    Generate prospective 9-construct experimental panel + controls with randomized plate layout (Job 283C).
    """
    _configure_stdio()
    from factorforge.discovery.acquisition_logger import AcquisitionLogger
    from factorforge.discovery.panel_builder import ProspectivePanelBuilder

    builder = ProspectivePanelBuilder(host=HOST_MAP.get(host, "nbenthamiana"))
    dataset, aux_data = builder.build_panel(
        replicates_per_construct=replicates,
        seed=seed,
        experiment_id=experiment_id,
    )

    out_p = Path(output_dir)
    logger = AcquisitionLogger(base_output_dir=out_p.parent)
    saved_dir = logger.export_prospective_panel(
        dataset=dataset,
        aux_data=aux_data,
        subfolder=out_p.name,
    )

    click.echo("\n=======================================================")
    click.echo("FactorForge Prospective DBTL Panel Built (Job 283C)")
    click.echo(f"Experiment ID: {experiment_id}")
    click.echo(f"Constructs: {len(dataset.constructs)} (9 experimental + 2 controls)")
    click.echo(f"Total Samples (Wells): {len(dataset.samples)} (N={replicates} replicates)")
    click.echo(f"Package Directory: {saved_dir}")
    click.echo(f"Dataset SHA-256: {dataset.archive_sha256}")
    click.echo("=======================================================\n")
    for tname, rep in aux_data["orthogonality_report"].items():
        click.echo(f"Target [{tname}] Orthogonality Gate: {'PASSED' if rep['orthogonality_passed'] else 'FAILED'}")
        for pair, d in rep["pairwise_distances"].items():
            click.echo(f"  - {pair}: distance = {d:.4f}")
    click.echo("\nArtifacts Generated:")
    click.echo("  1. panel_sequences.fasta (Synthesis FASTA)")
    click.echo("  2. synthesis_manifest.csv (Order Manifest)")
    click.echo("  3. blinded_plate_layout.json (Operator Infiltration Sheet)")
    click.echo("  4. unblinded_mapping.json (Cryptographic Mapping)")
    click.echo("  5. scientific_memory_panel.json (Sequence-Free Feature Store)")
    click.echo("  6. prospective_dbtl_dataset.json (Paired DBTL Dataset Container)")
    click.echo("  7. secure_archive_manifest.json (SHA-256 Tamper-Evident Index)\n")


@cli.command("ingest-outcome")
@click.argument("dataset_file", type=click.Path(exists=True))
@click.argument("measurements_file", type=click.Path(exists=True))
@click.option("--output", "-o", type=click.Path(), help="Output path for updated dataset JSON")
def ingest_outcome(dataset_file, measurements_file, output):
    """
    Ingest empirical wet-lab measurements into a PairedDBTLDataset container.
    """
    _configure_stdio()
    from factorforge.discovery.acquisition import PairedDBTLDataset
    from factorforge.discovery.acquisition_logger import AcquisitionLogger

    with open(dataset_file, "r", encoding="utf-8") as f:
        ds_dict = json.load(f)
    dataset = PairedDBTLDataset.from_dict(ds_dict)

    with open(measurements_file, "r", encoding="utf-8") as f:
        msr_data = json.load(f)

    if isinstance(msr_data, dict) and "measurements" in msr_data:
        raw_list = msr_data["measurements"]
    elif isinstance(msr_data, list):
        raw_list = msr_data
    else:
        raise click.UsageError("Measurements file must be a JSON array or object with 'measurements' key.")

    updated_ds = AcquisitionLogger.ingest_wet_lab_measurements(
        dataset=dataset,
        raw_measurements=raw_list,
    )

    out_path = output or dataset_file
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(updated_ds.to_dict(include_sequence=True), f, indent=2)

    click.echo("\n=======================================================")
    click.echo(f"Successfully Ingested {len(raw_list)} Wet-Lab Measurements")
    click.echo(f"Derived Outcomes Generated: {len(updated_ds.derived_outcomes)}")
    click.echo(f"Updated Dataset Saved: {out_path}")
    click.echo(f"Updated Archive SHA-256: {updated_ds.archive_sha256}")
    click.echo("=======================================================\n")



@cli.command("audit")
@click.argument("sequence_fasta", type=click.Path(exists=True))
@click.option("--reference-codon-profile", default="nbev11", help="Reference codon profile to use")
@click.option("--exclude-region", help="Region to exclude from analysis (e.g., SP:1-60 or 1-60)")
@click.option("--output", "-o", type=click.Path(), help="Output path for JSON report")
def audit(sequence_fasta, reference_codon_profile, exclude_region, output):
    """
    Run generic sequence audit to report codon usage, CAI, GC, and AA distribution.
    """
    _configure_stdio()
    import hashlib
    import json
    from pathlib import Path

    from factorforge.analysis.metrics import (
        calculate_cai,
        calculate_gc,
        calculate_max_synonymous_share,
        calculate_reference_distance,
        calculate_synonymous_entropy,
        codon_usage_profile,
        load_codon_usage_table,
        translate_dna,
    )
    from factorforge.engines.balanced_optimizer import STANDARD_GENETIC_CODE
    from factorforge.engines.profile.utils import parse_fasta_records
    
    fasta_records = parse_fasta_records(Path(sequence_fasta).read_text(encoding='utf-8'))
    if not fasta_records:
        raise click.UsageError(f"No FASTA records found in {sequence_fasta}")
    
    results = {}
    for header, sequence in fasta_records:
        seq = sequence.upper().replace("U", "T")
        seq = "".join(seq.split())
        
        if exclude_region:
            parts = exclude_region.split(":")
            range_str = parts[-1]
            try:
                start, end = map(int, range_str.split("-"))
                seq = seq[:start-1] + seq[end:]
            except ValueError:
                click.echo(f"Warning: Could not parse exclude region {exclude_region}", err=True)
                
        table_path = None
        if reference_codon_profile and reference_codon_profile != 'nbev11':
            table_path = Path(__file__).parent.parent / 'data' / "profiles" / f"{reference_codon_profile}_cds_hc_derived_codons.json"
            if not table_path.exists():
                click.echo(f"Warning: profile {reference_codon_profile} not found, falling back to default", err=True)
                table_path = None
                
        table = load_codon_usage_table(table_path)
        
        cai = calculate_cai(seq, table.codon_weights)
        gc = calculate_gc(seq)
        usage = codon_usage_profile(seq)
        
        aa_seq = translate_dna(seq)
        aa_counts = {}
        for aa in aa_seq:
            aa_counts[aa] = aa_counts.get(aa, 0) + 1
            
        entropy = calculate_synonymous_entropy(seq, STANDARD_GENETIC_CODE)
        max_share = calculate_max_synonymous_share(seq, STANDARD_GENETIC_CODE)
        ref_dist = calculate_reference_distance(seq, table.codon_weights, STANDARD_GENETIC_CODE)
        
        res = {
            "input_sha256": hashlib.sha256(sequence.encode('utf-8')).hexdigest(),
            "codon_table_sha256": hashlib.sha256(json.dumps(table.codon_weights, sort_keys=True).encode()).hexdigest(),
            "tool_version": "1.1",
            "cai": cai,
            "gc_percent": gc,
            "length": len(seq),
            "normalized_synonymous_entropy": entropy,
            "reference_distribution_distance": ref_dist,
            "max_synonymous_share": max_share,
            "aa_counts": aa_counts,
            "codon_counts": usage,
        }
        results[header or "Sequence"] = res

    if output:
        with open(output, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        click.echo(f"Audit report saved to: {output}")
    else:
        click.echo(json.dumps(results, indent=2))


cli.add_command(nbfold_cli)
cli.add_command(structure_cli)


@cli.command("self-update")
@click.option("--check", is_flag=True, help="Perform an explicit read-only update check.")
@click.option("--json", "json_output", is_flag=True, default=False, help="Output structured update report as JSON.")
@click.option("--timeout", default=2.0, type=float, help="Timeout in seconds for remote index query (default: 2.0).")
def self_update_cmd(check: bool, json_output: bool, timeout: float) -> None:
    """Explicit, read-only check for FactorForge distribution updates.

    Compares eligible installs against public PyPI without running an installer.
    """
    if not check:
        raise click.UsageError("Pass --check to request a read-only version comparison.")
    if not 0 < timeout <= 30:
        raise click.BadParameter("Expected a finite timeout in (0, 30] seconds.", param_hint="--timeout")
    result = check_factorforge_update(timeout=timeout)
    if json_output:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(format_update_report(result))



if __name__ == "__main__":
    cli()


