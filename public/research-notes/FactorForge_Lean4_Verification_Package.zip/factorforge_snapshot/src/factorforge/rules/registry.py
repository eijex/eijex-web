# factorforge/src/factorforge/rules/registry.py
"""Declarative Rule Registry for FactorForge bio-compiler.

Provides unified rule governance across biological invariants, assembly constraints,
synthesis risks, and regulatory recommendations.
"""

from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, List, Optional

from factorforge.rules.models import (
    AuthorizedAction,
    AuthorityType,
    EnforcementLevel,
    RuleAuthority,
    RuleCategory,
    RuleDefinition,
    RuleScope,
)


# ---------------------------------------------------------------------------
# Evaluator Implementations
# ---------------------------------------------------------------------------

def _check_bsai(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """BsaI Type IIS recognition site check (GGTCTC / GAGACC)."""
    seq_upper = sequence.upper()
    forward_matches = [m.start() for m in re.finditer(r"GGTCTC", seq_upper)]
    reverse_matches = [m.start() for m in re.finditer(r"GAGACC", seq_upper)]
    total_sites = len(forward_matches) + len(reverse_matches)
    return {
        "passed": total_sites == 0,
        "site_count": total_sites,
        "forward_positions": forward_matches,
        "reverse_positions": reverse_matches,
    }


def _check_bsmbi(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """BsmBI / Esp3I Type IIS recognition site check (CGTCTC / GAGACG)."""
    seq_upper = sequence.upper()
    forward_matches = [m.start() for m in re.finditer(r"CGTCTC", seq_upper)]
    reverse_matches = [m.start() for m in re.finditer(r"GAGACG", seq_upper)]
    total_sites = len(forward_matches) + len(reverse_matches)
    return {
        "passed": total_sites == 0,
        "site_count": total_sites,
        "forward_positions": forward_matches,
        "reverse_positions": reverse_matches,
    }


def _check_reading_frame(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """CDS length must be an exact multiple of 3 and start with ATG."""
    seq_upper = sequence.upper()
    is_multiple_3 = len(seq_upper) % 3 == 0
    starts_with_atg = seq_upper.startswith("ATG") if len(seq_upper) >= 3 else False
    passed = is_multiple_3 and starts_with_atg
    return {
        "passed": passed,
        "length": len(seq_upper),
        "is_multiple_of_three": is_multiple_3,
        "starts_with_atg": starts_with_atg,
    }


def _check_cryptic_splice(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """Plant/Eukaryotic canonical splice donor consensus motif ([A/C]AGGT[A/G]AGT)."""
    from factorforge.guards.plant_rna_guards import CRYPTIC_SPLICE_DONOR_PATTERN

    seq_clean = "".join(sequence.upper().split())
    donor_matches = [m.start() for m in CRYPTIC_SPLICE_DONOR_PATTERN.finditer(seq_clean)]
    return {
        "passed": len(donor_matches) == 0,
        "risk_count": len(donor_matches),
        "donor_positions": donor_matches,
    }


def _check_polya_signals(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """Premature polyadenylation signals (AATAAA, ATTAAA, AATAAT)."""
    from factorforge.guards.plant_rna_guards import PREMATURE_POLYA_PATTERN

    seq_clean = "".join(sequence.upper().split())
    polya_matches = [m.start() for m in PREMATURE_POLYA_PATTERN.finditer(seq_clean)]
    return {
        "passed": len(polya_matches) == 0,
        "count": len(polya_matches),
        "positions": polya_matches,
    }


def _check_au_rich_elements(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """AU-rich mRNA destabilizing elements (ATTTA / AUUUA)."""
    from factorforge.guards.plant_rna_guards import ARE_PATTERN

    seq_clean = "".join(sequence.upper().split())
    are_matches = [m.start() for m in ARE_PATTERN.finditer(seq_clean)]
    return {
        "passed": len(are_matches) == 0,
        "count": len(are_matches),
        "positions": are_matches,
    }


def _check_homopolymer_runs(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """Flag homopolymer runs >= 6 nt (synthesis yield risk)."""
    seq_upper = sequence.upper()
    runs = [m.span() for m in re.finditer(r"(A{6,}|C{6,}|G{6,}|T{6,})", seq_upper)]
    return {
        "passed": len(runs) == 0,
        "run_count": len(runs),
        "run_spans": runs,
    }


def _check_gc_extremes(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """Sliding window local GC extremes (window=50, threshold: <25% or >75%)."""
    seq_upper = sequence.upper()
    w = 50
    extreme_windows = []
    if len(seq_upper) >= w:
        for i in range(len(seq_upper) - w + 1):
            sub = seq_upper[i : i + w]
            gc = (sub.count("G") + sub.count("C")) / w
            if gc < 0.25 or gc > 0.75:
                extreme_windows.append((i, round(gc, 3)))
    return {
        "passed": len(extreme_windows) == 0,
        "extreme_count": len(extreme_windows),
        "extreme_windows": extreme_windows[:10],
    }


def _check_initiation_mfe_policy(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """Advisory check on 5' translation initiation window structural risk."""
    initiation_mfe = context.get("initiation_mfe")
    if initiation_mfe is None:
        return {
            "status": "not_available",
            "evaluated": False,
            "passed": None,
            "value": None,
            "details": "initiation_mfe metric not provided in context",
            "reason": "Missing initiation_mfe metric in evaluation context",
            "threshold": -3.0,
        }
    import math
    try:
        if isinstance(initiation_mfe,bool) or not math.isfinite(float(initiation_mfe)):
            raise ValueError()
        value = float(initiation_mfe)
    except (TypeError,ValueError,OverflowError):
        return {"status":"not_available","evaluated":False,"passed":None,"value":None,"reason":"Invalid initiation_mfe observation","threshold":-3.0}
    passed = value >= -3.0
    return {
        "status": "evaluated",
        "evaluated": True,
        "passed": passed,
        "value": float(initiation_mfe),
        "initiation_mfe": float(initiation_mfe),
        "threshold": -3.0,
    }


# ---------------------------------------------------------------------------
# Rule Registry Class
# ---------------------------------------------------------------------------


def _check_codon_concentration(sequence: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """Checks if any amino acid has >80% usage of a single codon (concentration)."""
    STANDARD_CODE = {
        'ATA':'I', 'ATC':'I', 'ATT':'I', 'ATG':'M',
        'ACA':'T', 'ACC':'T', 'ACG':'T', 'ACT':'T',
        'AAC':'N', 'AAT':'N', 'AAA':'K', 'AAG':'K',
        'AGC':'S', 'AGT':'S', 'AGA':'R', 'AGG':'R',
        'CTA':'L', 'CTC':'L', 'CTG':'L', 'CTT':'L',
        'CCA':'P', 'CCC':'P', 'CCG':'P', 'CCT':'P',
        'CAC':'H', 'CAT':'H', 'CAA':'Q', 'CAG':'Q',
        'CGA':'R', 'CGC':'R', 'CGG':'R', 'CGT':'R',
        'GTA':'V', 'GTC':'V', 'GTG':'V', 'GTT':'V',
        'GCA':'A', 'GCC':'A', 'GCG':'A', 'GCT':'A',
        'GAC':'D', 'GAT':'D', 'GAA':'E', 'GAG':'E',
        'GGA':'G', 'GGC':'G', 'GGG':'G', 'GGT':'G',
        'TCA':'S', 'TCC':'S', 'TCG':'S', 'TCT':'S',
        'TTC':'F', 'TTT':'F', 'TTA':'L', 'TTG':'L',
        'TAC':'Y', 'TAT':'Y', 'TAA':'*', 'TAG':'*',
        'TGC':'C', 'TGT':'C', 'TGA':'*', 'TGG':'W',
    }
    seq = "".join(sequence.upper().split())
    if len(seq) % 3 != 0:
        return {"status": "ok"} # Skip if not full CDS
        
    aa_counts = {}
    c_counts = {}
    for i in range(0, len(seq), 3):
        c = seq[i:i+3]
        aa = STANDARD_CODE.get(c, '*')
        if aa == '*':
            continue
        aa_counts[aa] = aa_counts.get(aa, 0) + 1
        c_counts[c] = c_counts.get(c, 0) + 1
        
    concentrated_aas = []
    for aa, total in aa_counts.items():
        if total < 5:
            continue  # Ignore rare AAs
        max_share = 0
        for c, a in STANDARD_CODE.items():
            if a == aa:
                share = c_counts.get(c, 0) / total
                if share > max_share:
                    max_share = share
        if max_share >= 0.80:
            concentrated_aas.append(f"{aa} (Max share: {max_share:.0%})")
            
    if concentrated_aas:
        return {
            "status": "finding",
            "message": f"High synonymous codon concentration detected for: {', '.join(concentrated_aas)}"
        }
    return {"status": "ok"}

def _check_additional_type_iis(sequence: str, context: dict[str, Any], motifs) -> dict[str, Any]:
    seq_upper = sequence.upper()
    forward = [m.start() for m in re.finditer(motifs[0], seq_upper)]
    reverse = [m.start() for m in re.finditer(motifs[1], seq_upper)]
    return {
        "passed": not (forward or reverse),
        "site_count": len(forward) + len(reverse),
        "forward_positions": forward,
        "reverse_positions": reverse,
    }


def _check_bpii(sequence: str, context: dict[str, Any]) -> dict[str, Any]:
    return _check_additional_type_iis(sequence, context, ("GAAGAC", "GTCTTC"))


def _check_sapi(sequence: str, context: dict[str, Any]) -> dict[str, Any]:
    return _check_additional_type_iis(sequence, context, ("GAAGAGC", "GCTCTTC"))


class RuleRegistry:
    """Registry managing collection of versioned, scoped, and attributed rules."""

    def __init__(self, ruleset_id: str = "default-assembly-2026.09", sop_profile=None):
        self.ruleset_id = ruleset_id
        self.sop_profile = sop_profile
        self._rules: Dict[str, RuleDefinition] = {}
        self._register_default_rules()

    def _register_default_rules(self) -> None:
        """Register the standard suite across Hard Invariants, Warnings, and Policies."""
        # Expose existing recognition targets to uploaded policy profiles.
        # Mandatory enforcement remains a user's profile decision.
        for rule_id, name, evaluator in (
            ("assembly.type_iis.bpii.v1", "BpiI Type IIS Absence", _check_bpii),
            ("assembly.type_iis.sapi.v1", "SapI Type IIS Absence", _check_sapi),
        ):
            self.register(
                RuleDefinition(
                    rule_id=rule_id,
                    name=name,
                    description="Configured Type IIS recognition-site scan on both strands.",
                    category=RuleCategory.ASSEMBLY,
                    enforcement=EnforcementLevel.WARNING,
                    authority=RuleAuthority(
                        authority_type=AuthorityType.EIJEX_INTERNAL_POLICY,
                        source_name="factorforge-sequence-policy-example",
                    ),
                    scope=RuleScope(molecule_types={"dna"}),
                    version="1.0.0",
                    evaluator_fn=evaluator,
                )
            )
        
        # 1. Hard Invariants (hard_fail)
        self.register(
            RuleDefinition(
                rule_id="assembly.type_iis.bsai.v1",
                name="BsaI Type IIS Absence",
                description="Strict exclusion of BsaI recognition sites (GGTCTC/GAGACC) for GoldenBraid / GoldenGate assembly.",
                category=RuleCategory.ASSEMBLY,
                enforcement=EnforcementLevel.HARD_FAIL,
                authority=RuleAuthority(
                    authority_type=AuthorityType.EIJEX_INTERNAL_POLICY,
                    source_name="assembly-profile-goldenbraid-v2",
                ),
                scope=RuleScope(
                    assembly_methods={"golden_gate", "golden_braid", "*"},
                    molecule_types={"dna"},
                ),
                version="1.0.0",
                evaluator_fn=_check_bsai,
            )
        )

        self.register(
            RuleDefinition(
                rule_id="assembly.type_iis.bsmbi.v1",
                name="BsmBI / Esp3I Type IIS Absence",
                description="Strict exclusion of BsmBI recognition sites (CGTCTC/GAGACG) for standard Level 2 GoldenGate assembly.",
                category=RuleCategory.ASSEMBLY,
                enforcement=EnforcementLevel.HARD_FAIL,
                authority=RuleAuthority(
                    authority_type=AuthorityType.EIJEX_INTERNAL_POLICY,
                    source_name="assembly-profile-goldengate-v1",
                ),
                scope=RuleScope(
                    assembly_methods={"golden_gate", "*"},
                    molecule_types={"dna"},
                ),
                version="1.0.0",
                evaluator_fn=_check_bsmbi,
            )
        )

        self.register(
            RuleDefinition(
                rule_id="biological.reading_frame.v1",
                name="CDS Reading Frame & Start Codon",
                description="CDS must have a length multiple of 3 and start with a valid ATG initiation codon.",
                category=RuleCategory.ASSEMBLY,
                enforcement=EnforcementLevel.HARD_FAIL,
                authority=RuleAuthority(
                    authority_type=AuthorityType.COMMUNITY_STANDARD,
                    source_name="standard_genetic_code",
                ),
                scope=RuleScope(molecule_types={"dna", "mrna"}),
                version="1.0.0",
                evaluator_fn=_check_reading_frame,
            )
        )

        # 2. Advisory Biological & RNA Risks (warning)
        self.register(
            RuleDefinition(
                rule_id="rna.cryptic_splice.v1",
                name="Eukaryotic Cryptic Splice Donor Risk",
                description="Advisory scan for canonical eukaryotic splice donor consensus motifs.",
                category=RuleCategory.RNA_RISK,
                enforcement=EnforcementLevel.WARNING,
                authority=RuleAuthority(
                    authority_type=AuthorityType.COMMUNITY_STANDARD,
                    source_name="plant_mrna_processing_standards",
                ),
                scope=RuleScope(
                    target_hosts={"Nicotiana benthamiana", "Arabidopsis thaliana", "Homo sapiens", "*"},
                    molecule_types={"dna", "mrna"},
                ),
                version="1.0.0",
                evaluator_fn=_check_cryptic_splice,
            )
        )

        self.register(
            RuleDefinition(
                rule_id="rna.polya_motifs.v1",
                name="Premature Polyadenylation Motif Risk",
                description="Advisory scan for premature polyadenylation consensus sequences (AATAAA/ATTAAA).",
                category=RuleCategory.RNA_RISK,
                enforcement=EnforcementLevel.WARNING,
                authority=RuleAuthority(
                    authority_type=AuthorityType.COMMUNITY_STANDARD,
                    source_name="eukaryotic_polyadenylation_guidelines",
                ),
                scope=RuleScope(molecule_types={"dna", "mrna"}),
                version="1.0.0",
                evaluator_fn=_check_polya_signals,
            )
        )

        self.register(
            RuleDefinition(
                rule_id="rna.au_rich_elements.v1",
                name="AU-Rich Destabilizing Elements (ARE)",
                description="Advisory scan for pentameric ATTTA motifs that mediate mRNA instability in eukaryotic hosts.",
                category=RuleCategory.RNA_RISK,
                enforcement=EnforcementLevel.WARNING,
                authority=RuleAuthority(
                    authority_type=AuthorityType.COMMUNITY_STANDARD,
                    source_name="mrna_decay_pathways",
                ),
                scope=RuleScope(molecule_types={"dna", "mrna"}),
                version="1.0.0",
                evaluator_fn=_check_au_rich_elements,
            )
        )

        self.register(
            RuleDefinition(
                rule_id="synthesis.gc_extremes.v1",
                name="Local GC Extremes (Sliding Window)",
                description="Flags local windows of 50 nt with GC < 25% or > 75% causing chemical synthesis dropout.",
                category=RuleCategory.INTERNAL_POLICY,
                enforcement=EnforcementLevel.WARNING,
                authority=RuleAuthority(
                    authority_type=AuthorityType.EIJEX_INTERNAL_POLICY,
                    source_name="eijex_synthesis_feasibility_guidelines",
                ),
                scope=RuleScope(molecule_types={"dna"}),
                version="1.0.0",
                evaluator_fn=_check_gc_extremes,
            )
        )

        # 3. Policy & Quality Recommendations (informational)
        self.register(
            RuleDefinition(
                rule_id="policy.synthesis.homopolymer.v1",
                name="Homopolymer Run Length Limit",
                description="Eijex policy recommendation to avoid mono-nucleotide runs >= 6 nt for gene synthesis yield.",
                category=RuleCategory.INTERNAL_POLICY,
                enforcement=EnforcementLevel.INFORMATIONAL,
                authority=RuleAuthority(
                    authority_type=AuthorityType.EIJEX_INTERNAL_POLICY,
                    source_name="eijex_gene_synthesis_standards_2026",
                ),
                scope=RuleScope(molecule_types={"dna"}),
                version="1.0.0",
                evaluator_fn=_check_homopolymer_runs,
            )
        )

        self.register(
            RuleDefinition(
                rule_id="policy.initiation_mfe.v1",
                name="5' Translation Initiation Structural Relaxation",
                description="Quality indicator for 5' initiation region secondary structure (target MFE >= -3.0 kcal/mol).",
                category=RuleCategory.INTERNAL_POLICY,
                enforcement=EnforcementLevel.INFORMATIONAL,
                authority=RuleAuthority(
                    authority_type=AuthorityType.EIJEX_INTERNAL_POLICY,
                    source_name="eijex_dp_v2_1_initiation_spec",
                ),
                scope=RuleScope(molecule_types={"dna", "mrna"}),
                version="1.0.0",
                evaluator_fn=_check_initiation_mfe_policy,
            )
        )

    def register(self, rule: RuleDefinition) -> None:
        """Register or update a rule definition."""
        self._rules[rule.rule_id] = rule

    def resolved_enforcement(self, rule: RuleDefinition) -> EnforcementLevel:
        if self.sop_profile is not None:
            return self.sop_profile.get_enforcement(rule.rule_id)
        return rule.enforcement

    def resolved_authorized_action(self, rule: RuleDefinition) -> AuthorizedAction:
        if self.sop_profile is not None:
            return self.sop_profile.get_authorized_action(rule.rule_id)
        return AuthorizedAction.BLOCK if self.resolved_enforcement(rule) == EnforcementLevel.HARD_FAIL else AuthorizedAction.REPORT_ONLY

    def get_rule(self, rule_id: str) -> Optional[RuleDefinition]:
        """Retrieve rule by ID."""
        return self._rules.get(rule_id)

    def list_rules(
        self,
        assembly_method: Optional[str] = None,
        host: Optional[str] = None,
        enforcement: Optional[EnforcementLevel] = None,
    ) -> List[RuleDefinition]:
        """Filter rules by context and enforcement level."""
        results = []
        for rule in self._rules.values():
            if not rule.scope.matches(assembly_method=assembly_method, host=host):
                continue
            if enforcement and self.resolved_enforcement(rule) != enforcement:
                continue
            results.append(rule)
        return results

    def evaluate_sequence(
        self,
        sequence: str,
        assembly_method: Optional[str] = None,
        host: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Evaluate all applicable rules and aggregate results by enforcement level."""
        active_rules = self.list_rules(assembly_method=assembly_method, host=host)
        ctx = context or {}

        hard_fails = []
        warnings = []
        info_items = []
        not_available = []
        all_passed = True

        for rule in active_rules:
            res = rule.evaluate(sequence, ctx)
            passed = res.get("passed")
            is_evaluated = res.get("evaluated", passed is not None)
            resolved_enforcement = self.resolved_enforcement(rule)
            resolved_action = self.resolved_authorized_action(rule)
            entry = {
                "rule_id": rule.rule_id,
                "name": rule.name,
                "enforcement": resolved_enforcement.value,
                "authorized_action": resolved_action.value,
                "authority": rule.authority.authority_type.value,
                "result": res,
            }

            if not is_evaluated or passed is None:
                entry["status"] = "not_available"
                not_available.append(entry)
                if resolved_enforcement == EnforcementLevel.HARD_FAIL:
                    entry["authorized_action"] = AuthorizedAction.BLOCK.value
                    entry["required_unavailable"] = True
                    hard_fails.append(entry)
                    all_passed = False
                continue

            if not passed:
                if resolved_enforcement == EnforcementLevel.HARD_FAIL:
                    hard_fails.append(entry)
                    all_passed = False
                elif resolved_enforcement == EnforcementLevel.WARNING:
                    warnings.append(entry)
                else:
                    info_items.append(entry)

        return {
            "ruleset_id": self.ruleset_id,
            "ruleset_digest": self.compute_digest(),
            "all_passed": all_passed,
            "hard_fail_count": len(hard_fails),
            "warning_count": len(warnings),
            "not_available_count": len(not_available),
            "required_unavailable_count": sum(bool(e.get("required_unavailable")) for e in not_available),
            "evaluation_status": ("INCOMPLETE" if any(e.get("required_unavailable") for e in not_available) else "FAILED" if hard_fails else "COMPLETE_WITH_OPTIONAL_UNAVAILABLE" if not_available else "COMPLETE"),
            "hard_fails": hard_fails,
            "warnings": warnings,
            "informational": info_items,
            "not_available": not_available,
        }

    def compute_digest(self) -> str:
        """Compute cryptographic SHA-256 fingerprint of the current rule registry."""
        rule_summaries = sorted([
            f"{r.rule_id}:{r.version}:{self.resolved_enforcement(r).value}:{self.resolved_authorized_action(r).value}:{r.authority.authority_type.value}"
            for r in self._rules.values()
        ])
        raw_text = ";".join(rule_summaries).encode("utf-8")
        return f"sha256:{hashlib.sha256(raw_text).hexdigest()}"
