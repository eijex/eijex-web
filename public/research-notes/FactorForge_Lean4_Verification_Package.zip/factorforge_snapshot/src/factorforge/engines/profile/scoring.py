"""
Multidimensional Scoring for FactorForge profile engine.
Composite scoring function with optional ViennaRNA MFE integration.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Literal

logger = logging.getLogger(__name__)

# GC band for the current N. benthamiana software-default codon reference.
# NbeV1.1 high-confidence CDS-derived codon usage anchors the public default
# to the native genome-derived composition band. This is a configured
# in-silico reference/GC policy, not wet-lab validation or expression/yield
# prediction. Sequences inside [GC_OPT_MIN, GC_OPT_MAX] receive full GC score;
# outside the band the score decays linearly.
GC_OPT_MIN = 40.0
GC_OPT_MAX = 47.0
GC_OPT_MID = 43.5  # kept for gc_target point-scoring and viral_delivery centering
GC_DECAY_WIDTH = 20.0  # percentage points outside band before score reaches 0.0

# Host-isolation fix: ntabacum/BY-2 must not silently inherit the NbeV1.1
# N. benthamiana band. Other hosts keep the pre-v3.3.0 global default until
# they get their own host-specific analysis.
GC_RANGE_DEFAULT: tuple[float, float] = (55.0, 65.0)
GC_RANGES_BY_HOST: dict[str, tuple[float, float]] = {
    "nbenthamiana": (GC_OPT_MIN, GC_OPT_MAX),
}


def resolve_host_gc_range(host: str | None) -> tuple[float, float]:
    """Resolve the (gc_min, gc_max) composition band for a host.

    nbenthamiana uses the reference-policy audit native genome-composition anchor.
    Any other host (including unknown ones) keeps the pre-v3.3.0 global
    default band until it gets its own host-specific analysis.
    """
    return GC_RANGES_BY_HOST.get(host or "nbenthamiana", GC_RANGE_DEFAULT)


def resolve_host_gc_mid(host: str | None) -> float:
    """Resolve the GC band midpoint for a host (see resolve_host_gc_range)."""
    gc_min, gc_max = resolve_host_gc_range(host)
    return (gc_min + gc_max) / 2

# ViennaRNA availability cache
_vienna_available: bool | None = None


@dataclass
class ScoringConfig:
    """Scoring weight configuration for composite optimization score."""

    w_cai: float = 0.5
    w_gc: float = 0.3
    w_mfe: float = 0.2
    w_dinuc: float = 0.0  # CpG/TpA dinucleotide penalty (opt-in, default off)
    cpg_weight: float = 0.0  # plant default: CpG inactive
    tpa_weight: float = 1.0  # plant default: TpA active
    w_syncodonlm: float = 0.0  # SynCodonLM quality score (opt-in, default off)
    gc_opt: float = GC_OPT_MID  # no longer used by calculate_composite_score (superseded by
                                # gc_min/gc_max band); retained for external API compatibility
    gc_min: float = GC_OPT_MIN  # acceptable band lower boundary
    gc_max: float = GC_OPT_MAX  # acceptable band upper boundary
    gc_decay_width: float = GC_DECAY_WIDTH  # % points outside band before score → 0
    use_mfe: bool = True

    def __post_init__(self) -> None:
        """Validate inputs, then normalize weights to sum to 1.0."""
        for field_name in ("w_cai", "w_gc", "w_mfe", "w_dinuc", "w_syncodonlm"):
            if getattr(self, field_name) < 0:
                raise ValueError(f"{field_name} must be >= 0, got {getattr(self, field_name)}")
        if self.gc_min > self.gc_max:
            raise ValueError(f"gc_min ({self.gc_min}) must be <= gc_max ({self.gc_max})")
        self._normalize()

    def _normalize(self) -> None:
        """Ensure active weights sum to 1.0."""
        total = (
            self.w_cai
            + self.w_gc
            + (self.w_mfe if self.use_mfe else 0.0)
            + self.w_dinuc
            + self.w_syncodonlm
        )
        if total > 0:
            self.w_cai /= total
            self.w_gc /= total
            if self.use_mfe:
                self.w_mfe /= total
            else:
                self.w_mfe = 0.0
            self.w_dinuc /= total
            self.w_syncodonlm /= total


# Pre-defined scoring configs per optimization profile
PROFILE_SCORING_CONFIGS: dict[str, ScoringConfig] = {
    "balanced": ScoringConfig(w_cai=0.5, w_gc=0.3, w_mfe=0.2),
    # high_cai: CAI 1.0 mimics naturally high-expression N. benthamiana genes (golden_set).
    # For very long or structurally complex proteins under extreme agroinfiltration overexpression,
    # consider the ramp profile instead (N-terminal codon deoptimization reduces ribosome stalling).
    "high_cai": ScoringConfig(w_cai=0.8, w_gc=0.1, w_mfe=0.1),
    # gc_target: gc_min/gc_max are overridden dynamically from target_gc kwarg in
    # calculate_composite_score — the config defaults here are not used for band scoring.
    "gc_target": ScoringConfig(w_cai=0.1, w_gc=0.7, w_mfe=0.2),
    # assembly_friendly: CAI pressure reduced vs balanced; GC/MFE weights raised to
    # reflect Type IIS restriction-site avoidance priority (Golden Gate / MoClo).
    # w_gc scores GC band compliance (global GC%), NOT local GC uniformity.
    # Window-level GC variance and repeat-pattern penalties are not yet implemented.
    "assembly_friendly": ScoringConfig(w_cai=0.3, w_gc=0.4, w_mfe=0.3),
    "ramp": ScoringConfig(w_cai=0.4, w_gc=0.3, w_mfe=0.3),
    # TRV viral-delivery profile — GC band centered on TRV genome composition (~47.5%).
    # MFE weighted at 0.30 (Peccoud et al. 2024, PMC11718241).
    "viral_delivery": ScoringConfig(
        w_cai=0.35, w_gc=0.35, w_mfe=0.30,
        gc_opt=47.5, gc_min=37.5, gc_max=57.5,
        use_mfe=True,
    ),
    "ml_enhanced": ScoringConfig(w_cai=0.35, w_gc=0.25, w_mfe=0.15, w_syncodonlm=0.25),
}


def _check_vienna_available() -> bool:
    """Check if ViennaRNA Python bindings are available."""
    global _vienna_available
    if _vienna_available is None:
        try:
            import RNA  # noqa: F401

            _vienna_available = True
            logger.debug("ViennaRNA Python bindings available")
        except ImportError:
            _vienna_available = False
            logger.debug("ViennaRNA not available; MFE scoring disabled")
    return _vienna_available


# ViennaRNA's RNA.fold() uses Zuker's MFE algorithm, O(n^3) time /
# O(n^2) memory — there was previously no length guard anywhere in the
# calculate_mfe() call chain, so a single request at/under the existing
# public API length limits (5000aa/15000bp) could pin a CPU core for minutes
# (algorithmic-complexity DoS, CWE-407; confirmed via faulthandler stack
# traces + an isolated RNA.fold() timing curve: 1000nt ~2.2s, 2000nt ~9.8s,
# 3000nt ~24.6s). calculate_mfe() is called twice per optimize() call
# (once for scoring, once independently for compute_mfe_evidence()
# provenance), so the real per-request cost is ~2x this curve. 1000nt
# (~333aa) keeps worst-case cost to roughly 4-5s even with that doubling,
# while still covering most realistic single-protein CDS design requests.
MFE_MAX_SEQUENCE_LENGTH = 1000

MFEStatus = Literal["computed", "not_computed"]
MFEReason = Literal[
    "disabled_for_profile",
    "no_input",
    "missing_dependency",
    "length_exceeded",
    "computation_failed",
]


@dataclass(frozen=True)
class MFEResolution:
    """Resolved MFE value plus human and machine-readable provenance."""

    value: float | None
    status: MFEStatus
    reason: MFEReason | None
    warning: str | None


def _fold_mfe(sequence: str) -> float | None:
    """Run ViennaRNA folding after caller-side availability/length guards."""
    try:
        import RNA

        # Convert DNA to RNA (T → U)
        rna_seq = sequence.upper().replace("T", "U")
        _, mfe = RNA.fold(rna_seq)
        return float(mfe)
    except Exception as exc:
        logger.debug(f"MFE calculation failed: {exc}")
        return None


def _resolve_mfe_status(sequence: str | None, config: ScoringConfig) -> MFEResolution:
    """Resolve MFE computation result without collapsing skip/failure reasons."""
    if not config.use_mfe:
        return MFEResolution(
            value=None,
            status="not_computed",
            reason="disabled_for_profile",
            warning="MFE scoring is disabled for this profile.",
        )

    if sequence is None:
        return MFEResolution(
            value=None,
            status="not_computed",
            reason="no_input",
            warning="MFE was not computed because no sequence was provided.",
        )

    if not _check_vienna_available():
        return MFEResolution(
            value=None,
            status="not_computed",
            reason="missing_dependency",
            warning="MFE was not computed because ViennaRNA is unavailable in this environment.",
        )

    if len(sequence) > MFE_MAX_SEQUENCE_LENGTH:
        logger.warning(
            "Sequence length (%d nt) exceeds MFE_MAX_SEQUENCE_LENGTH (%d nt); "
            "skipping global MFE calculation to avoid an unbounded ViennaRNA "
            "RNA.fold() runtime (O(n^3)). MFE scoring falls back to a neutral, "
            "zero-weighted contribution for this candidate.",
            len(sequence), MFE_MAX_SEQUENCE_LENGTH,
        )
        return MFEResolution(
            value=None,
            status="not_computed",
            reason="length_exceeded",
            warning=(
                f"MFE was skipped because the sequence ({len(sequence)} nt) exceeds "
                f"the {MFE_MAX_SEQUENCE_LENGTH} nt limit for global MFE folding."
            ),
        )

    mfe_value = _fold_mfe(sequence)
    if mfe_value is None:
        return MFEResolution(
            value=None,
            status="not_computed",
            reason="computation_failed",
            warning="MFE computation failed for this sequence.",
        )

    return MFEResolution(value=mfe_value, status="computed", reason=None, warning=None)


def calculate_mfe(sequence: str) -> float | None:
    """
    Calculate minimum free energy (MFE) using ViennaRNA.

    Args:
        sequence: DNA or RNA sequence.

    Returns:
        MFE in kcal/mol, or None if ViennaRNA is not available or the
        sequence exceeds MFE_MAX_SEQUENCE_LENGTH.
    """
    return _resolve_mfe_status(sequence, PROFILE_SCORING_CONFIGS["balanced"]).value


def normalize_mfe(mfe: float, seq_length: int) -> float:
    """
    Normalize MFE to 0-1 range where 1 = no structure (favorable).

    Clamp range calibrated empirically from internal computational audit data:
    measured MFE/nt across 135 FactorForge outputs (N. benthamiana +
    BY-2 hosts, 5 profiles) ranged -0.4064 to -0.1338 (combined 5th/95th
    percentile -0.3839/-0.1760). The range below widens that empirical
    percentile by a margin on both sides to avoid saturating ~10% of
    future sequences at the score floor/ceiling.

    Args:
        mfe: Minimum free energy in kcal/mol.
        seq_length: Sequence length in nucleotides.

    Returns:
        Normalized MFE score (0-1) under this computational normalization,
        where a higher value represents a less negative whole-CDS MFE/nt.
        This is a Tier-0 computational heuristic only — no
        biological interpretation (translation efficiency, mRNA stability,
        or expression outcome) is implied or validated.
    """
    if seq_length == 0:
        return 0.5

    mfe_per_nt = mfe / seq_length
    # Clamp to empirically calibrated range [-0.40, -0.15] (analysis 011)
    clamped = max(-0.40, min(-0.15, mfe_per_nt))
    # Map to [0, 1] where -0.15 kcal/mol/nt → 1.0 and -0.40 → 0.0
    return (clamped + 0.40) / 0.25


def gc_band_score(
    gc: float,
    gc_min: float,
    gc_max: float,
    decay_width: float = GC_DECAY_WIDTH,
) -> float:
    """Score GC content against an acceptable band.

    Returns 1.0 inside [gc_min, gc_max]; linearly decays to 0.0 after
    decay_width percentage points outside the band.

    Args:
        gc: GC content percentage (0-100).
        gc_min: Lower boundary of acceptable band.
        gc_max: Upper boundary of acceptable band.
        decay_width: Percentage points outside band before score reaches 0.0.

    Examples:
        gc_min=55, gc_max=65, decay_width=20:
          gc=60 → 1.00  (inside band)
          gc=70 → 0.75  (5 pts above gc_max)
          gc=80 → 0.25  (15 pts above gc_max)
          gc=85 → 0.00  (20 pts above gc_max)
    """
    if gc_min <= gc <= gc_max:
        return 1.0
    distance = (gc_min - gc) if gc < gc_min else (gc - gc_max)
    return max(0.0, 1.0 - distance / decay_width)


def calculate_dinucleotide_score(
    sequence: str,
    cpg_weight: float = 0.0,
    tpa_weight: float = 1.0,
) -> float:
    """Score dinucleotide avoidance.

    Plant default: CpG inactive (cpg_weight=0.0), only TpA is penalized.
    Mammalian opt-in: set cpg_weight=1.0 and tpa_weight=1.0 to penalize both.
    """
    from factorforge.analysis.metrics import calculate_dinucleotide_score as _score

    return _score(sequence, cpg_weight=cpg_weight, tpa_weight=tpa_weight)


def calculate_composite_score(
    cai: float,
    gc: float,
    sequence: str | None = None,
    config: ScoringConfig | None = None,
    profile: str | None = None,
    host: str | None = None,
    **kwargs: Any,
) -> float:
    """Calculate multidimensional composite score.

    S = w1*CAI + w2*gc_band_score + w3*MFE_norm
        + w4*dinuc_score + w5*SynCodonLM_score

    GC scoring uses a band function: sequences inside [gc_min, gc_max] receive
    full score (1.0); outside the band the score decays linearly to 0.0 over
    gc_decay_width percentage points. For gc_target profile, the band is
    centred on the caller-supplied target_gc (±5 pp).

    Args:
        cai: Codon Adaptation Index (0-1).
        gc: GC content percentage (0-100).
        sequence: DNA sequence for optional MFE, dinucleotide, and SynCodonLM calculation.
        config: Explicit ScoringConfig. Overrides profile.
        profile: Profile name for preset config lookup.
        **kwargs: target_gc (float) — point target for gc_target profile.

    Returns:
        Composite score (0-1).
    """
    # Resolve config
    if config is None:
        profile_name = (profile or "balanced").lower()
        config = PROFILE_SCORING_CONFIGS.get(profile_name)
        if config is None:
            supported = ", ".join(sorted(PROFILE_SCORING_CONFIGS))
            raise ValueError(
                f"Unknown profile: {profile_name}. Supported profiles: {supported}"
            )
        if "target_gc" in kwargs and profile_name != "gc_target":
            raise ValueError("target_gc is only valid for the gc_target profile")

    # Component 1: CAI (already 0-1)
    cai_score = max(0.0, min(1.0, cai))

    # Component 2: GC band scoring
    # gc_target profile: caller supplies target_gc; use a ±5 pp band around it.
    # All other profiles: use the band defined in ScoringConfig (gc_min/gc_max).
    if "target_gc" in kwargs:
        tgt = float(kwargs["target_gc"])
        gc_score = gc_band_score(gc, tgt - 5.0, tgt + 5.0, config.gc_decay_width)
    else:
        gc_min, gc_max = config.gc_min, config.gc_max
        # Profiles that haven't customized the band (still on the
        # GC_OPT_MIN/MAX default) follow the active host's composition band.
        # Profiles with an explicit band override (e.g. viral_delivery) keep
        # it regardless of host — that override is profile-specific, not a
        # host default.
        if (gc_min, gc_max) == (GC_OPT_MIN, GC_OPT_MAX):
            gc_min, gc_max = resolve_host_gc_range(host)
        gc_score = gc_band_score(gc, gc_min, gc_max, config.gc_decay_width)

    # Component 3: MFE (optional)
    mfe_score = 0.5  # neutral default
    actual_w_mfe = config.w_mfe

    if config.use_mfe and sequence is not None and _check_vienna_available():
        mfe = calculate_mfe(sequence)
        if mfe is not None:
            mfe_score = normalize_mfe(mfe, len(sequence))
        else:
            actual_w_mfe = 0.0
    else:
        actual_w_mfe = 0.0

    # Component 4: Dinucleotide avoidance (opt-in, default weight 0.0)
    dinuc_score = 0.5  # neutral default
    actual_w_dinuc = config.w_dinuc
    if actual_w_dinuc > 0 and sequence is not None:
        dinuc_score = calculate_dinucleotide_score(
            sequence,
            cpg_weight=config.cpg_weight,
            tpa_weight=config.tpa_weight,
        )
    elif actual_w_dinuc > 0:
        actual_w_dinuc = 0.0  # Cannot compute without sequence

    # Component 5: SynCodonLM score (opt-in, default weight 0.0)
    syncodonlm_score = 0.5  # neutral default
    actual_w_syncodonlm = config.w_syncodonlm
    if actual_w_syncodonlm > 0 and sequence is not None:
        from factorforge.engines.profile.scoring_ml import calculate_syncodonlm_score

        organism = str(kwargs.get("organism", "Nicotiana_benthamiana"))
        syncodonlm_score = calculate_syncodonlm_score(sequence, organism=organism)
    elif actual_w_syncodonlm > 0:
        actual_w_syncodonlm = 0.0  # Cannot compute without sequence

    # Compute weighted score (re-normalize if optional components are disabled)
    w_total = config.w_cai + config.w_gc + actual_w_mfe + actual_w_dinuc + actual_w_syncodonlm
    if w_total == 0:
        return 0.0

    score = (
        (config.w_cai / w_total) * cai_score
        + (config.w_gc / w_total) * gc_score
        + (actual_w_mfe / w_total) * mfe_score
        + (actual_w_dinuc / w_total) * dinuc_score
        + (actual_w_syncodonlm / w_total) * syncodonlm_score
    )

    return round(score, 3)


def compute_mfe_evidence(
    sequence: str | None,
    config: ScoringConfig | None = None,
    profile: str | None = None,
) -> dict[str, Any]:
    """Return MFE provenance metadata for a scored sequence.

    Mirrors the MFE branch of ``calculate_composite_score`` WITHOUT changing the
    score. Its purpose is honesty: when MFE is not computed (e.g. ViennaRNA is
    unavailable in the deployment, as on Vercel), callers must be able to tell
    that ``mfe_kcal_mol`` is absent rather than a genuine 0.0.

    Returns a dict with:
        mfe_kcal_mol: float | None   (None when not computed)
        mfe_status:   "computed" | "not_computed"
        mfe_status_reason: str | None (machine-readable reason when not computed)
        mfe_used:     bool           (whether MFE contributed to the score)
        mfe_warning:  str | None     (reason when not used)
        score_components: {cai_used, gc_used, mfe_used}
    """
    if config is None:
        profile_name = (profile or "balanced").lower()
        config = PROFILE_SCORING_CONFIGS.get(profile_name) or PROFILE_SCORING_CONFIGS["balanced"]

    resolution = _resolve_mfe_status(sequence, config)
    mfe_used = resolution.value is not None
    return {
        "mfe_kcal_mol": round(resolution.value, 2) if mfe_used else None,
        "mfe_status": resolution.status,
        "mfe_status_reason": resolution.reason,
        "mfe_used": mfe_used,
        "mfe_warning": resolution.warning,
        "score_components": {"cai_used": True, "gc_used": True, "mfe_used": mfe_used},
    }


def compute_5p_mfe_evidence(
    cds_sequence: str | None,
    upstream_context: str | None = None,
    window_nt: int = 60,
) -> dict[str, Any]:
    """Compute true MFE of the 5' initiation transcript window.

    Constructs fold window: contiguous upstream context + start codon + 5' CDS (up to window_nt).
    """
    if not cds_sequence:
        return {
            "mfe_5p_window_kcal_mol": None,
            "mfe_5p_status": "not_computed",
            "mfe_5p_reason": "no_input",
            "mfe_5p_warning": "No CDS sequence provided.",
            "fold_window_nt": 0,
        }

    up = (upstream_context or "").strip().upper()
    cds = cds_sequence.strip().upper()

    # Build contiguous transcript window
    # If upstream context exists, take last 15-20nt of upstream + first 45-60nt of CDS
    if up:
        up_tail = up[-15:] if len(up) > 15 else up
        target_window = (up_tail + cds)[:window_nt]
    else:
        target_window = cds[:window_nt]

    if not _check_vienna_available():
        return {
            "mfe_5p_window_kcal_mol": None,
            "mfe_5p_status": "not_computed",
            "mfe_5p_reason": "missing_dependency",
            "mfe_5p_warning": "ViennaRNA unavailable in this environment.",
            "fold_window_nt": len(target_window),
        }

    mfe_val = _fold_mfe(target_window)
    if mfe_val is None:
        return {
            "mfe_5p_window_kcal_mol": None,
            "mfe_5p_status": "not_computed",
            "mfe_5p_reason": "computation_failed",
            "mfe_5p_warning": "5' window MFE computation failed.",
            "fold_window_nt": len(target_window),
        }

    return {
        "mfe_5p_window_kcal_mol": round(mfe_val, 2),
        "mfe_5p_status": "computed",
        "mfe_5p_reason": None,
        "mfe_5p_warning": None,
        "fold_window_nt": len(target_window),
    }

