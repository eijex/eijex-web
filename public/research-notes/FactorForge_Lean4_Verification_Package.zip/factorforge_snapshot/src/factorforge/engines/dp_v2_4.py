"""Experimental max-plus DP with optional positional pause-ramp interpolation.

The historical TASEP/Wasserstein/entropy API names are compatibility labels.
This module has no particle-exclusion traffic simulator, calibrated elongation
rates, normalized probability-mass transport distance or spectral-radius entropy.
Post-hoc diagnostics are sequence-weight proxies, not biological measurements.
Unused nonzero shock/transport objective weights are explicitly rejected.
Zero-weight/no-smoothing parity is tested on fixtures, not a universal proof.
UNVERIFIED_PUBLIC_CORPUS. Biological validation: NOT_AVAILABLE.
"""

from __future__ import annotations

import math
from collections.abc import Iterable
from typing import Any, ClassVar

from factorforge.analysis.metrics import STANDARD_GENETIC_CODE, detect_homopolymers
from factorforge.constraints.type_iis import TYPE_IIS_MOTIFS, resolve_restriction_site_motifs
from factorforge.engines.dp_v2_3 import StructuralPauseAnnotator
from factorforge.engines.profile.scoring import compute_5p_mfe_evidence
from factorforge.engines.sllm.automaton import AutomatonCompiler, CompiledAutomaton
from factorforge.utils.exceptions import UnsatisfiableDesignError

AA_TO_CODONS: dict[str, list[str]] = {}
for codon, aa in STANDARD_GENETIC_CODE.items():
    if aa != "*":
        AA_TO_CODONS.setdefault(aa, []).append(codon)


class TropicalSemiring:
    """Tropical Max-Plus Semiring: (R U {-inf}, max, +)."""

    ZERO = -float("inf")
    ONE = 0.0

    @classmethod
    def oplus(cls, a: float, b: float) -> float:
        """Tropical addition: a oplus b = max(a, b)."""
        return max(a, b)

    @classmethod
    def otimes(cls, a: float, b: float) -> float:
        """Tropical multiplication: a otimes b = a + b."""
        if a == cls.ZERO or b == cls.ZERO:
            return cls.ZERO
        return a + b


class TASEPKineticsEngine:
    """Legacy-named positional ramp and adjacent-weight proxy helpers; not a TASEP simulator."""

    RIBOSOME_FOOTPRINT_CODONS = 10  # Standard eukaryotic ribosome footprint ~30 nt

    @classmethod
    def compute_smoothed_pause_map(
        cls,
        protein: str,
        active_pause_map: dict[int, list[tuple[str, float, float]]],
        smoothing_window: int = 3,
    ) -> dict[int, list[tuple[str, float, float]]]:
        """Distributes steep deceleration points over an upstream ramp window to prevent traffic jams.

        For each annotated pause position p with target tau_k:
        Positions p - d (for d in 1..smoothing_window-1) receive an interpolated buffer rate.
        """
        smoothed_map: dict[int, list[tuple[str, float, float]]] = {}
        for pos, annot_list in active_pause_map.items():
            smoothed_map.setdefault(pos, []).extend(annot_list)

        for pos, annot_list in active_pause_map.items():
            for c_name, weight, target_tau in annot_list:
                for d in range(1, smoothing_window):
                    upstream_pos = pos - d
                    if upstream_pos >= 1 and upstream_pos not in active_pause_map:
                        ramp_tau = round(
                            target_tau + (float(d) / smoothing_window) * (1.0 - target_tau), 3
                        )
                        ramp_weight = round(weight * (1.0 - float(d) / smoothing_window) * 0.5, 3)
                        smoothed_map.setdefault(upstream_pos, []).append(
                            (f"{c_name}_RAMP_d{d}", ramp_weight, ramp_tau)
                        )
        return smoothed_map

    @classmethod
    def evaluate_shock_potential(
        cls,
        sequence: str,
        codon_weights: dict[str, float],
        shock_threshold: float = 0.45,
    ) -> dict[str, Any]:
        """Describes relative adjacent codon-weight drops, not collisions or measured rates."""
        codons = [sequence[i : i + 3] for i in range(0, len(sequence), 3)]
        rates = [codon_weights.get(c, 0.5) for c in codons]
        shocks: list[dict[str, Any]] = []

        for i in range(1, len(rates)):
            prev_rate = rates[i - 1]
            curr_rate = rates[i]
            drop = prev_rate - curr_rate
            rel_drop = drop / (prev_rate + 1e-6)
            if rel_drop > shock_threshold:
                shocks.append(
                    {
                        "position": i + 1,
                        "prev_codon": codons[i - 1],
                        "prev_rate": round(prev_rate, 3),
                        "curr_codon": codons[i],
                        "curr_rate": round(curr_rate, 3),
                        "relative_drop": round(rel_drop, 3),
                    }
                )

        mean_rate = sum(rates) / len(rates) if rates else 0.0
        collision_index = sum(s["relative_drop"] for s in shocks) / max(1, len(rates))

        return {
            "scope": "ADJACENT_CODON_WEIGHT_PROXY_NOT_COLLISION_MODEL",
            "rate_units": "NOT_AVAILABLE",
            "total_shocks_detected": len(shocks),
            "collision_index": round(collision_index, 4),
            "shock_details": shocks[:10],
            "mean_elongation_rate": round(mean_rate, 3),
        }


class WassersteinCadenceEvaluator:
    """Legacy name for mean cumulative reciprocal-weight discrepancy, not normalized W1."""

    @classmethod
    def evaluate_1d_wasserstein(
        cls,
        sequence: str,
        codon_weights: dict[str, float],
        target_pause_map: dict[int, list[tuple[str, float, float]]],
        default_tau: float = 1.0,
    ) -> float:
        """Returns a reciprocal-weight trajectory proxy; units/time calibration unavailable."""
        codons = [sequence[i : i + 3] for i in range(0, len(sequence), 3)]
        n = len(codons)
        if n == 0:
            return 0.0

        cum_cand_time = 0.0
        cum_target_time = 0.0
        total_l1_diff = 0.0

        for i, c in enumerate(codons):
            pos = i + 1
            w_c = max(0.01, codon_weights.get(c, 0.5))
            cum_cand_time += 1.0 / w_c

            if pos in target_pause_map:
                taus = [ann[2] for ann in target_pause_map[pos]]
                tau_target = max(0.01, sum(taus) / len(taus))
            else:
                tau_target = default_tau
            cum_target_time += 1.0 / tau_target

            total_l1_diff += abs(cum_cand_time - cum_target_time)

        return round(total_l1_diff / float(n), 4)


class TransferMatrixFeasibilityGuard:
    """Prefix DFA reachability diagnostic, not full-design feasibility or topological entropy."""

    @classmethod
    def check_feasibility(
        cls,
        protein: str,
        automaton: CompiledAutomaton,
        ramp_length: int = 15,
    ) -> dict[str, Any]:
        """Pre-checks non-empty language reachability across first ramp_length codons."""
        active_states: set[int] = {0}
        n_check = min(len(protein), ramp_length)

        for i in range(n_check):
            aa = protein[i]
            codons = AA_TO_CODONS.get(aa, [])
            next_states: set[int] = set()
            for s in active_states:
                for c in codons:
                    succ, is_forbidden = automaton.step_codon(s, c)
                    if not is_forbidden:
                        next_states.add(succ)
            active_states = next_states
            if not active_states:
                return {
                    "feasible": False,
                    "failed_at_codon": i + 1,
                    "topological_entropy": 0.0,
                    "scope": "PREFIX_REACHABILITY_ONLY",
                    "entropy_is_calibrated": False,
                }

        h_top = math.log(max(1, len(active_states))) / float(max(1, n_check))
        return {
            "feasible": True,
            "failed_at_codon": None,
            "topological_entropy": round(h_top, 4),  # deprecated alias, not spectral entropy
            "log_reachable_state_count_per_codon": round(h_top, 4),
            "scope": "PREFIX_REACHABILITY_ONLY",
            "entropy_is_calibrated": False,
            "surviving_states_at_ramp": len(active_states),
        }


class DPV240Optimizer:
    """Experimental max-plus DP; optional positional ramp, diagnostic-only trajectory proxies."""

    DEFAULT_CLASS_PARAMS: ClassVar[dict[str, dict[str, Any]]] = {
        "SP": {"weight": 2.0, "target_tau": 0.35, "description": "Signal peptide cleavage site"},
        "SS": {"weight": 2.0, "target_tau": 0.45, "description": "Disulfide loop chaperone pause"},
        "TM": {"weight": 3.0, "target_tau": 0.25, "description": "Transmembrane domain entry/exit"},
        "GLYC": {"weight": 1.0, "target_tau": 0.45, "description": "N-linked glycosylation dwell"},
        "HINGE": {"weight": 0.5, "target_tau": 0.70, "description": "Inter-domain flexible hinge"},
        "CUSTOM": {"weight": 2.0, "target_tau": 0.45, "description": "User-specified custom pause"},
    }

    def __init__(
        self,
        forbidden_enzymes: Iterable[str] | None = ("BsaI", "BsmBI", "NotI"),
        forbidden_motifs: Iterable[str] | None = None,
        include_reverse_complement: bool = True,
        ramp_length_codons: int = 15,
        alpha_harmonization: float = 1.0,
        beta_mfe_proxy: float = 1.0,
        gamma_gc_penalty: float = 0.5,
        delta_au_bonus: float = 0.5,
        r_ramp_start: float = 0.50,
        r_ramp_end: float = 0.90,
        homopolymer_max_run: int = 5,
        initiation_gc_min: float = 0.20,
        initiation_gc_max: float = 0.30,
        nominal_ramp_gc: float = 0.25,
        pause_positions: Iterable[int] | None = None,
        pause_target_adaptiveness: float = 0.45,
        pause_penalty_weight: float = 0.0,
        auto_annotate_pauses: bool = False,
        pause_classes: dict[str, dict[str, Any]] | None = None,
        structure_reference: str | None = None,
        enable_tasep_smoothing: bool = False,
        tasep_smoothing_window: int = 3,
        lambda_tasep_shock: float = 0.0,
        lambda_ot_cadence: float = 0.0,
    ) -> None:
        for value in (lambda_tasep_shock, lambda_ot_cadence):
            if type(value) not in (int, float) or not math.isfinite(value) or value != 0:
                raise ValueError(
                    "Nonzero or invalid shock/transport objective weights are unsupported"
                )
        if type(enable_tasep_smoothing) is not bool:
            raise TypeError("enable_tasep_smoothing must be bool")
        if type(tasep_smoothing_window) is not int or tasep_smoothing_window < 1:
            raise ValueError("tasep_smoothing_window must be a positive integer")
        self.literal_motifs = (
            tuple(sorted({motif.strip().upper() for motif in forbidden_motifs}))
            if forbidden_motifs is not None
            else None
        )
        if self.literal_motifs is not None:
            if any(not motif or set(motif) - set("ACGT") for motif in self.literal_motifs):
                raise ValueError("Forbidden motifs must be nonempty literal DNA strings")
            self.enzyme_names = ()
            self.resolved_enzyme_motifs = ()
        else:
            self.enzyme_names = tuple(
                TYPE_IIS_MOTIFS if forbidden_enzymes is None else forbidden_enzymes
            )
            self.resolved_enzyme_motifs = tuple(resolve_restriction_site_motifs(self.enzyme_names))
        motifs = list(
            self.resolved_enzyme_motifs if self.literal_motifs is None else self.literal_motifs
        )

        self.homopolymer_max_run = homopolymer_max_run
        if self.homopolymer_max_run > 0:
            for base in ("A", "T", "G", "C"):
                poly = base * (self.homopolymer_max_run + 1)
                if poly not in motifs:
                    motifs.append(poly)

        self.include_reverse_complement = include_reverse_complement
        effective_motifs = set(motifs)
        if include_reverse_complement:
            effective_motifs.update(AutomatonCompiler.reverse_complement(motif) for motif in motifs)
        self.effective_motifs = tuple(sorted(effective_motifs))
        self.automaton: CompiledAutomaton = AutomatonCompiler.compile(
            self.effective_motifs, include_rc=False
        )
        self.ramp_length_codons = ramp_length_codons
        self.alpha = alpha_harmonization
        self.beta = beta_mfe_proxy
        self.gamma = gamma_gc_penalty
        self.delta = delta_au_bonus
        self.r_start = r_ramp_start
        self.r_end = r_ramp_end
        self.initiation_gc_min = initiation_gc_min
        self.initiation_gc_max = initiation_gc_max
        self.nominal_ramp_gc = nominal_ramp_gc
        self.auto_annotate_pauses = auto_annotate_pauses
        self.structure_reference = structure_reference or "none"

        # TASEP & Optimal Transport Configuration
        self.enable_tasep_smoothing = enable_tasep_smoothing
        self.tasep_smoothing_window = tasep_smoothing_window
        self.lambda_tasep_shock = lambda_tasep_shock
        self.lambda_ot_cadence = lambda_ot_cadence

        # Multi-Class Structural Pause Conditioning
        self.configured_classes: dict[str, dict[str, Any]] = {}
        for cls_name, defaults in self.DEFAULT_CLASS_PARAMS.items():
            self.configured_classes[cls_name] = {
                "positions": set(),
                "weight": defaults["weight"],
                "target_tau": defaults["target_tau"],
            }

        if pause_classes:
            for c_name, c_cfg in pause_classes.items():
                if c_name not in self.configured_classes:
                    self.configured_classes[c_name] = {
                        "positions": set(),
                        "weight": 2.0,
                        "target_tau": 0.45,
                    }
                if "positions" in c_cfg:
                    self.configured_classes[c_name]["positions"] = set(c_cfg["positions"])
                if "weight" in c_cfg:
                    self.configured_classes[c_name]["weight"] = float(c_cfg["weight"])
                if "target_tau" in c_cfg:
                    self.configured_classes[c_name]["target_tau"] = float(c_cfg["target_tau"])

        if pause_positions is not None:
            c_pos = set(pause_positions)
            self.configured_classes["CUSTOM"]["positions"].update(c_pos)
            self.configured_classes["CUSTOM"]["weight"] = pause_penalty_weight
            self.configured_classes["CUSTOM"]["target_tau"] = pause_target_adaptiveness

        if self.ramp_length_codons < 1:
            raise ValueError("ramp_length_codons must be at least 1")
        if self.homopolymer_max_run < 1:
            raise ValueError("homopolymer_max_run must be at least 1")
        if not 0.0 <= self.initiation_gc_min <= self.initiation_gc_max <= 1.0:
            raise ValueError("initiation GC bounds must satisfy 0 <= min <= max <= 1")

    def _resolve_active_pause_map(self, protein: str) -> dict[int, list[tuple[str, float, float]]]:
        """Resolves active pause map, applying TASEP upstream collision smoothing if enabled."""
        active_map: dict[int, list[tuple[str, float, float]]] = {}

        # 1. Base configured classes
        for c_name, c_data in self.configured_classes.items():
            w = c_data["weight"]
            tau = c_data["target_tau"]
            if w > 0.0:
                for pos in c_data["positions"]:
                    active_map.setdefault(pos, []).append((c_name, w, tau))

        # 2. Automated structural pause annotation
        if self.auto_annotate_pauses:
            detected = StructuralPauseAnnotator.annotate(protein)
            for c_name, positions in detected.items():
                defaults = self.configured_classes.get(
                    c_name,
                    self.DEFAULT_CLASS_PARAMS.get(c_name, {"weight": 2.0, "target_tau": 0.45}),
                )
                w = defaults["weight"]
                tau = defaults["target_tau"]
                if w > 0.0:
                    for pos in positions:
                        active_map.setdefault(pos, []).append((c_name, w, tau))

        # 3. TASEP upstream ramp smoothing
        if self.enable_tasep_smoothing and active_map:
            active_map = TASEPKineticsEngine.compute_smoothed_pause_map(
                protein, active_map, smoothing_window=self.tasep_smoothing_window
            )

        return active_map

    def compute_codon_log_fitness(
        self,
        position_idx: int,
        codon: str,
        codon_weights: dict[str, float],
        active_pause_map: dict[int, list[tuple[str, float, float]]],
    ) -> float:
        """Computes position-dependent structural log-fitness score w_struct(i, c)."""
        w = codon_weights.get(codon, 1e-4)

        # 1. Base piecewise fitness ell_i(c)
        if position_idx >= self.ramp_length_codons:
            # Stage 2: Elongation Body -> Host Log-CAI
            base_fitness = math.log(max(w, 1e-6))
        else:
            # Stage 1: Initiation Ramp (0 <= position_idx < K)
            denom = max(1, self.ramp_length_codons - 1)
            r_i = self.r_start + (self.r_end - self.r_start) * (position_idx / float(denom))
            h_score = -abs(w - r_i)
            g_count = codon.count("G") + codon.count("C")
            au_count = 3 - g_count
            pen_open = -self.gamma * g_count + self.delta * au_count
            base_fitness = self.alpha * h_score + self.beta * pen_open

        # 2. Multi-class structural pause penalty
        one_based_pos = position_idx + 1
        if one_based_pos in active_pause_map:
            pause_penalty = sum(
                w_pen * abs(w - target_tau)
                for _, w_pen, target_tau in active_pause_map[one_based_pos]
            )
            return base_fitness - pause_penalty

        return base_fitness

    def optimize(
        self,
        protein_sequence: str,
        codon_weights: dict[str, float],
        target_gc_min: float = 0.40,
        target_gc_max: float = 0.47,
        upstream_context: str = "",
        stop_codon: str = "TAA",
        downstream_context: str = "",
        allow_nearest_infeasible: bool = False,
        left_flank: str | None = None,
        right_flank: str | None = None,
    ) -> dict[str, Any]:
        """Optimizes the implemented finite-state score; diagnostic proxies do not alter it."""
        up_ctx = left_flank if left_flank is not None else upstream_context
        down_ctx = right_flank if right_flank is not None else downstream_context

        clean_protein = "".join(protein_sequence.upper().split()).rstrip("*")
        if not clean_protein:
            raise ValueError("protein_sequence must not be empty")

        for aa in clean_protein:
            if aa not in AA_TO_CODONS:
                raise ValueError(f"Invalid amino acid character: '{aa}'")

        # Pre-check feasibility using Transfer Matrix
        feasibility_check = TransferMatrixFeasibilityGuard.check_feasibility(
            clean_protein, self.automaton, ramp_length=self.ramp_length_codons
        )
        if not feasibility_check["feasible"]:
            raise UnsatisfiableDesignError(
                f"DP v2.4.0 A Priori Feasibility Guard: sequence dead-ends at codon "
                f"{feasibility_check['failed_at_codon']} under full construct automaton constraints."
            )

        n_codons = len(clean_protein)
        total_nt = n_codons * 3

        up_ctx_clean = "".join(up_ctx.upper().split())
        down_ctx_clean = "".join(down_ctx.upper().split())
        stop_clean = "".join(stop_codon.upper().split())
        for seq, label in [
            (up_ctx_clean, "upstream"),
            (down_ctx_clean, "downstream"),
            (stop_clean, "stop"),
        ]:
            if any(b not in "ACGT" for b in seq):
                raise ValueError(f"Invalid character in {label} context: '{seq}'")

        gc_min_frac = max(0.0, min(1.0, target_gc_min))
        gc_max_frac = max(0.0, min(1.0, target_gc_max))
        if gc_min_frac > gc_max_frac:
            raise ValueError("target_gc_min cannot be greater than target_gc_max")

        min_gc_count = math.ceil(total_nt * gc_min_frac)
        max_gc_count = math.floor(total_nt * gc_max_frac)

        # Precompute Synonymous GC Envelope Bounds
        syn_min_possible_gc = [0] * (n_codons + 1)
        syn_max_possible_gc = [0] * (n_codons + 1)
        for i, aa in enumerate(clean_protein):
            possible_gcs = [sum(1 for b in c if b in "GC") for c in AA_TO_CODONS[aa]]
            syn_min_possible_gc[i + 1] = syn_min_possible_gc[i] + min(possible_gcs)
            syn_max_possible_gc[i + 1] = syn_max_possible_gc[i] + max(possible_gcs)

        total_min_possible_gc = syn_min_possible_gc[n_codons]
        total_max_possible_gc = syn_max_possible_gc[n_codons]

        if (
            max_gc_count < total_min_possible_gc or min_gc_count > total_max_possible_gc
        ) and not allow_nearest_infeasible:
            raise UnsatisfiableDesignError(
                f"DP v2.4.0: Target GC band [{gc_min_frac * 100:.1f}%, {gc_max_frac * 100:.1f}%] "
                f"is physically unreachable. Synonymous achievable range: "
                f"[{total_min_possible_gc / total_nt * 100:.1f}%, {total_max_possible_gc / total_nt * 100:.1f}%]."
            )

        # 5' Initiation Ramp GC Constraints at codon i = K = ramp_length_codons
        ramp_k = min(self.ramp_length_codons, n_codons)
        ramp_nt = ramp_k * 3
        apply_initiation_gc_guard = n_codons >= self.ramp_length_codons
        nom_init_min = math.ceil(self.initiation_gc_min * ramp_nt)
        nom_init_max = math.floor(self.initiation_gc_max * ramp_nt)
        if nom_init_min > nom_init_max:
            mid_init = round(self.nominal_ramp_gc * ramp_nt)
            nom_init_min = mid_init
            nom_init_max = mid_init

        ramp_min_possible_gc = sum(
            min(c.count("G") + c.count("C") for c in AA_TO_CODONS[aa])
            for aa in clean_protein[:ramp_k]
        )
        ramp_max_possible_gc = sum(
            max(c.count("G") + c.count("C") for c in AA_TO_CODONS[aa])
            for aa in clean_protein[:ramp_k]
        )

        init_min_gc_count = max(nom_init_min, ramp_min_possible_gc)
        init_max_gc_count = min(nom_init_max, ramp_max_possible_gc)
        initiation_gc_status = (
            "REQUESTED_BAND" if apply_initiation_gc_guard else "NOT_APPLIED_SHORT_SEQUENCE"
        )
        if apply_initiation_gc_guard and (
            init_min_gc_count != nom_init_min or init_max_gc_count != nom_init_max
        ):
            initiation_gc_status = "SYNONYMOUS_ENVELOPE_CLAMPED"
        if init_min_gc_count > init_max_gc_count:
            if apply_initiation_gc_guard:
                initiation_gc_status = "SYNONYMOUS_ENVELOPE_CLAMPED"
            if ramp_min_possible_gc > nom_init_max:
                init_min_gc_count = ramp_min_possible_gc
                init_max_gc_count = min(ramp_min_possible_gc + 2, ramp_max_possible_gc)
            else:
                init_max_gc_count = ramp_max_possible_gc
                init_min_gc_count = max(ramp_max_possible_gc - 2, ramp_min_possible_gc)

        # Resolve active pause map
        active_pause_map = self._resolve_active_pause_map(clean_protein)

        # Initial automaton state from upstream_context
        start_state = 0
        for char in up_ctx_clean:
            start_state = self.automaton.step_nucleotide(start_state, char)
            if start_state in self.automaton.terminal_states:
                raise UnsatisfiableDesignError(
                    f"DP v2.4.0: Upstream context contains forbidden motif: '{up_ctx}'"
                )

        # Dynamic Programming Layers using Tropical Semiring
        dp_layers: list[
            dict[tuple[int, int], tuple[float, str | None, int | None, int | None, int]]
        ] = []
        dp_layers.append({(0, start_state): (TropicalSemiring.ONE, None, None, None, 0)})
        step_codon = self.automaton.step_codon
        step_cache: dict[int, dict[str, tuple[int, bool]]] = {}

        for i, aa in enumerate(clean_protein):
            current_layer = dp_layers[-1]
            next_layer: dict[
                tuple[int, int], tuple[float, str | None, int | None, int | None, int]
            ] = {}
            codon_info = [
                (
                    codon,
                    codon.count("G") + codon.count("C"),
                    self.compute_codon_log_fitness(i, codon, codon_weights, active_pause_map),
                )
                for codon in AA_TO_CODONS[aa]
            ]
            is_ramp_boundary = i == ramp_k - 1

            for (g, s), (score, _, _, _, prev_path_rank) in current_layer.items():
                s_trans = step_cache.get(s)
                if s_trans is None:
                    s_trans = {}
                    step_cache[s] = s_trans
                for codon, codon_gc, step_log_fitness in codon_info:
                    # 1. Automaton Veto (cached per automaton state & codon)
                    transition = s_trans.get(codon)
                    if transition is None:
                        transition = step_codon(s, codon)
                        s_trans[codon] = transition
                    next_s, is_forbidden = transition
                    if is_forbidden:
                        continue

                    # 2. Cumulative GC count and Tropical multiplication score
                    next_g = g + codon_gc
                    next_score = TropicalSemiring.otimes(score, step_log_fitness)

                    state_key = (next_g, next_s)
                    existing = next_layer.get(state_key)
                    if existing is None:
                        next_layer[state_key] = (next_score, codon, g, s, prev_path_rank)
                    else:
                        (
                            existing_score,
                            existing_codon,
                            _existing_prev_g,
                            _existing_prev_s,
                            existing_prev_rank,
                        ) = existing
                        if next_score > existing_score + 1e-12:
                            next_layer[state_key] = (next_score, codon, g, s, prev_path_rank)
                        elif abs(next_score - existing_score) <= 1e-12:
                            cand_key = (prev_path_rank, codon)
                            exist_key = (existing_prev_rank, existing_codon)
                            if cand_key < exist_key:
                                next_layer[state_key] = (next_score, codon, g, s, prev_path_rank)

            if not next_layer:
                raise UnsatisfiableDesignError(
                    f"DP v2.4.0: State space exhausted at position {i + 1} ({aa}). "
                    f"No synonymous codon path satisfies the full construct automaton constraints."
                )

            # Exact 5' Initiation GC Band Hard Pruning at i = ramp_k - 1
            if is_ramp_boundary and apply_initiation_gc_guard:
                filtered_layer = {
                    k_st: v
                    for k_st, v in next_layer.items()
                    if init_min_gc_count <= k_st[0] <= init_max_gc_count
                }
                if filtered_layer:
                    next_layer = filtered_layer
                else:
                    initiation_gc_status = "AUTOMATON_REACHABILITY_RELAXED"
                    min_dist_to_band = min(
                        0
                        if init_min_gc_count <= k_st[0] <= init_max_gc_count
                        else min(abs(k_st[0] - init_min_gc_count), abs(k_st[0] - init_max_gc_count))
                        for k_st in next_layer
                    )
                    next_layer = {
                        k_st: v
                        for k_st, v in next_layer.items()
                        if (
                            0
                            if init_min_gc_count <= k_st[0] <= init_max_gc_count
                            else min(
                                abs(k_st[0] - init_min_gc_count), abs(k_st[0] - init_max_gc_count)
                            )
                        )
                        == min_dist_to_band
                    }
                    reachable_counts = [state[0] for state in next_layer]
                    init_min_gc_count = min(reachable_counts)
                    init_max_gc_count = max(reachable_counts)

            # Assign canonical path_rank to all active states
            sorted_states = sorted(
                next_layer.keys(), key=lambda k_st: (next_layer[k_st][4], next_layer[k_st][1])
            )
            rank_map = {st: idx for idx, st in enumerate(sorted_states)}
            compacted_layer: dict[
                tuple[int, int], tuple[float, str | None, int | None, int | None, int]
            ] = {}
            for st, (sc, cd, pg, ps, pr) in next_layer.items():
                compacted_layer[st] = (sc, cd, pg, ps, rank_map[st])

            dp_layers.append(compacted_layer)

        final_layer = dp_layers[-1]
        s_tail = (stop_clean + down_ctx_clean).upper()

        # Filter states compatible with full construct tail
        valid_final_states: list[
            tuple[tuple[int, int], tuple[float, str | None, int | None, int | None, int]]
        ] = []
        for (g, s), val in final_layer.items():
            curr = s
            tail_valid = True
            for char in s_tail:
                curr = self.automaton.step_nucleotide(curr, char)
                if curr in self.automaton.terminal_states:
                    tail_valid = False
                    break
            if tail_valid:
                valid_final_states.append(((g, s), val))

        if not valid_final_states:
            raise UnsatisfiableDesignError(
                f"DP v2.4.0: No candidate satisfies full construct tail constraints "
                f"(STOP='{stop_clean}', Downstream='{down_ctx_clean}')."
            )

        # Candidate Selection: Multi-tier tie breaking
        target_mid_gc_count = (min_gc_count + max_gc_count) / 2.0
        in_band_candidates = [
            item for item in valid_final_states if min_gc_count <= item[0][0] <= max_gc_count
        ]

        if in_band_candidates:
            best_item = max(
                in_band_candidates,
                key=lambda item: (
                    item[1][0],  # Primary: Total piecewise DP score J(X)
                    -abs(item[0][0] - target_mid_gc_count),  # Tie 1: Distance to target GC midpoint
                    -item[1][4],  # Tie 2: Full-path canonical LexRank
                ),
            )
            gc_feasible = True
        else:
            if not allow_nearest_infeasible:
                raise UnsatisfiableDesignError(
                    f"DP v2.4.0: Failed to satisfy target GC band [{gc_min_frac * 100:.1f}%, {gc_max_frac * 100:.1f}%]."
                )
            best_item = min(
                valid_final_states,
                key=lambda item: (
                    min(abs(item[0][0] - min_gc_count), abs(item[0][0] - max_gc_count)),
                    -item[1][0],
                    abs(item[0][0] - target_mid_gc_count),
                    item[1][4],
                ),
            )
            gc_feasible = False

        best_state, (best_score, _, _, _, _) = best_item

        # Traceback to reconstruct optimal CDS
        chosen_codons: list[str] = []
        curr_g, curr_s = best_state

        for layer_idx in range(n_codons, 0, -1):
            val = dp_layers[layer_idx][(curr_g, curr_s)]
            codon = val[1]
            assert codon is not None
            chosen_codons.append(codon)
            curr_g = val[2]
            curr_s = val[3]

        chosen_codons.reverse()
        optimized_dna = "".join(chosen_codons)

        # Full construct assembly & invariant verification
        full_construct = up_ctx_clean + optimized_dna + stop_clean + down_ctx_clean
        for motif in self.effective_motifs:
            if motif in full_construct:
                raise AssertionError(f"Forbidden motif invariant violation: found {motif}")

        # Metrics computation
        global_gc = sum(1 for b in optimized_dna if b in "GC") / float(total_nt)
        ramp_dna = optimized_dna[: ramp_k * 3]
        ramp_gc = sum(1 for b in ramp_dna if b in "GC") / float(max(1, len(ramp_dna)))
        body_dna = optimized_dna[ramp_k * 3 :]
        body_gc = (
            sum(1 for b in body_dna if b in "GC") / float(max(1, len(body_dna)))
            if body_dna
            else ramp_gc
        )

        global_cai = math.exp(
            sum(math.log(max(0.001, codon_weights.get(c, 0.05))) for c in chosen_codons) / n_codons
        )
        ramp_codons = chosen_codons[:ramp_k]
        ramp_cai = math.exp(
            sum(math.log(max(0.001, codon_weights.get(c, 0.05))) for c in ramp_codons)
            / max(1, len(ramp_codons))
        )
        body_codons = chosen_codons[ramp_k:]
        body_cai = (
            math.exp(
                sum(math.log(max(0.001, codon_weights.get(c, 0.05))) for c in body_codons)
                / len(body_codons)
            )
            if body_codons
            else ramp_cai
        )

        # Sliding window GC (50 bp window, 10 bp step)
        window_size = 50
        step = 10
        gc_windows = []
        if len(optimized_dna) >= window_size:
            for w_start in range(0, len(optimized_dna) - window_size + 1, step):
                w_seq = optimized_dna[w_start : w_start + window_size]
                gc_windows.append(sum(1 for b in w_seq if b in "GC") / float(window_size))
        else:
            gc_windows.append(global_gc)

        homopolymers = detect_homopolymers(optimized_dna, max_run=self.homopolymer_max_run + 1)
        mfe_evidence = compute_5p_mfe_evidence(
            cds_sequence=optimized_dna,
            upstream_context=up_ctx_clean,
        )

        # TASEP & Optimal Transport Kinetics Evaluation
        tasep_kinetics = TASEPKineticsEngine.evaluate_shock_potential(
            optimized_dna, codon_weights, shock_threshold=0.45
        )
        wasserstein_ot_distance = WassersteinCadenceEvaluator.evaluate_1d_wasserstein(
            optimized_dna, codon_weights, active_pause_map
        )

        # Summary of structural pause classes
        pause_report: list[dict[str, Any]] = []
        for pos in sorted(active_pause_map.keys()):
            c_idx = pos - 1
            if c_idx < len(chosen_codons):
                cd = chosen_codons[c_idx]
                cd_w = codon_weights.get(cd, 0.5)
                for c_name, w, tau in active_pause_map[pos]:
                    pause_report.append(
                        {
                            "position": pos,
                            "class": c_name,
                            "chosen_codon": cd,
                            "codon_weight": round(cd_w, 4),
                            "target_tau": tau,
                            "penalty_weight": w,
                            "deviation": round(abs(cd_w - tau), 4),
                        }
                    )

        class_counts = {}
        for item in pause_report:
            c = item["class"]
            class_counts[c] = class_counts.get(c, 0) + 1

        return {
            "sequence": optimized_dna,
            "score": best_score,
            "protein_length": n_codons,
            "total_nt": total_nt,
            "gc_percent": round(global_gc * 100.0, 2),
            "gc_feasible": gc_feasible,
            "motif_policy": {
                "enzyme_names": list(self.enzyme_names),
                "resolved_enzyme_motifs": list(self.resolved_enzyme_motifs),
                "literal_motifs": list(self.literal_motifs)
                if self.literal_motifs is not None
                else None,
                "include_reverse_complement": self.include_reverse_complement,
                "effective_motifs": list(self.effective_motifs),
            },
            "gc_min_target": gc_min_frac,
            "gc_max_target": gc_max_frac,
            "initiation_gc_status": initiation_gc_status,
            "initiation_gc_requested_min_count": nom_init_min,
            "initiation_gc_requested_max_count": nom_init_max,
            "initiation_gc_active_min_count": init_min_gc_count,
            "initiation_gc_active_max_count": init_max_gc_count,
            "initiation_gc_synonymous_min_count": ramp_min_possible_gc,
            "initiation_gc_synonymous_max_count": ramp_max_possible_gc,
            "gc_5p_45nt_percent": round(ramp_gc * 100.0, 2),
            "gc_body_percent": round(body_gc * 100.0, 2),
            "sliding_window_gc": {
                "window_size_bp": window_size,
                "step_bp": step,
                "min_window_gc_percent": round(min(gc_windows) * 100.0, 2),
                "max_window_gc_percent": round(max(gc_windows) * 100.0, 2),
                "mean_window_gc_percent": round((sum(gc_windows) / len(gc_windows)) * 100.0, 2),
            },
            "cai_global": round(global_cai, 4),
            "cai_ramp_45nt": round(ramp_cai, 4),
            "cai_body": round(body_cai, 4),
            "mfe_5p_evidence": mfe_evidence,
            "max_homopolymer_run": (
                max([hp["length"] for hp in homopolymers], default=0)
                if homopolymers
                else self.homopolymer_max_run
            ),
            "homopolymers_detected": homopolymers,
            "pause_conditioning": {
                "auto_annotated": self.auto_annotate_pauses,
                "tasep_smoothing_enabled": self.enable_tasep_smoothing,
                "classes": class_counts,
                "total_active_positions": len(active_pause_map),
                "details": pause_report,
            },
            "kinetics_and_transport": {
                "scope": "POSTHOC_WEIGHT_PROXIES_NOT_BIOPHYSICAL_VALIDATION",
                "cadence_metric": "MEAN_ABSOLUTE_CUMULATIVE_RECIPROCAL_WEIGHT_DIFFERENCE",
                "is_normalized_wasserstein": False,
                "evidence_tier": "UNVERIFIED_PUBLIC_CORPUS",
                "biological_validation": "NOT_AVAILABLE",
                "tasep": tasep_kinetics,
                "wasserstein_1d_cadence_distance": wasserstein_ot_distance,
                "transfer_matrix_feasibility": feasibility_check,
            },
            "engine_version": "2.4.0",
        }


class DPV240EngineAdapter:
    """FactorForge Profile Engine adapter for DPV240Optimizer."""

    def __init__(self, optimizer: DPV240Optimizer | None = None) -> None:
        self.optimizer = optimizer or DPV240Optimizer()

    def optimize_cds(
        self,
        protein_sequence: str,
        codon_weights: dict[str, float],
        target_gc_min: float = 0.40,
        target_gc_max: float = 0.47,
        upstream_context: str = "",
        stop_codon: str = "TAA",
        downstream_context: str = "",
        allow_nearest_infeasible: bool = False,
    ) -> dict[str, Any]:
        return self.optimizer.optimize(
            protein_sequence=protein_sequence,
            codon_weights=codon_weights,
            target_gc_min=target_gc_min,
            target_gc_max=target_gc_max,
            upstream_context=upstream_context,
            stop_codon=stop_codon,
            downstream_context=downstream_context,
            allow_nearest_infeasible=allow_nearest_infeasible,
        )
