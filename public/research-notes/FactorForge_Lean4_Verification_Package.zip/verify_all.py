"""Fail-closed one-command reproducible verifier for FactorForge Lean 4 & Python correspondence."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FORMAL_DIR = ROOT / "formal"
TESTS_DIR = ROOT / "tests"
FACTORFORGE_DIR = ROOT / "factorforge_snapshot"


def _find_elan_bin(tool: str) -> str:
    found = shutil.which(tool)
    if found:
        return found
    for suffix in (".exe", ""):
        cand = Path.home() / ".elan" / "bin" / f"{tool}{suffix}"
        if cand.exists():
            return str(cand)
    raise RuntimeError(f"Required Lean tool '{tool}' not found on PATH or ~/.elan/bin")


def _run(cmd: list[str], cwd: Path, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    print(f"[RUN] ({cwd.name}) {' '.join(cmd)}", flush=True)
    proc = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True, text=True, encoding="utf-8", check=False)
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit(proc.returncode)
    if proc.stdout:
        print(proc.stdout.rstrip(), flush=True)
    return proc


def _verify_reproducibility_manifest() -> None:
    repro_path = ROOT / "REPRODUCIBILITY_MANIFEST.json"
    if not repro_path.exists():
        raise SystemExit(f"Missing reproducibility manifest: {repro_path}")
    data = json.loads(repro_path.read_text(encoding="utf-8-sig"))

    source_hashes = data["factorforge_repository"]["tracked_files_sha256"]
    source_files = {
        f.relative_to(FACTORFORGE_DIR).as_posix()
        for f in FACTORFORGE_DIR.rglob("*")
        if f.is_file() and "__pycache__" not in f.parts and f.suffix != ".pyc"
    }
    if set(source_hashes) != source_files or not source_files:
        raise SystemExit("Source snapshot inventory differs from manifest")
    required_package_files = {
        f.relative_to(ROOT).as_posix()
        for folder, pattern in ((FORMAL_DIR, "*.lean"), (TESTS_DIR, "*.py"))
        for f in folder.rglob(pattern)
        if ".lake" not in f.parts
    } | {
        "verify_all.py", "formal/lakefile.toml", "formal/lake-manifest.json",
        "formal/lean-toolchain", "formal/spec_lock_manifest.json",
        "README.md", "formal/README.md", "PROOF_COVERAGE_MATRIX.md",
    }
    if set(data["package_files_sha256"]) != required_package_files:
        raise SystemExit("Verification input inventory differs from manifest")

    for rel_path, expected in source_hashes.items():
        p = FACTORFORGE_DIR / rel_path
        if not p.exists():
            raise SystemExit(f"Missing FactorForge file referenced in manifest: {p}")
        actual = hashlib.sha256(p.read_bytes()).hexdigest().upper()
        if actual != expected.upper():
            raise SystemExit(f"FactorForge SHA-256 mismatch on {rel_path}: {actual} != {expected}")

    for rel_path, expected in data["package_files_sha256"].items():
        p = ROOT / rel_path
        if not p.exists():
            raise SystemExit(f"Missing package file referenced in manifest: {p}")
        actual = hashlib.sha256(p.read_bytes()).hexdigest().upper()
        if actual != expected.upper():
            raise SystemExit(f"Package SHA-256 mismatch on {rel_path}: {actual} != {expected}")
    print(
        f"[OK] Verified REPRODUCIBILITY_MANIFEST.json across "
        f"{len(data['factorforge_repository']['tracked_files_sha256'])} FactorForge files and "
        f"{len(data['package_files_sha256'])} package files."
    )


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    env = os.environ.copy()
    elan_bin = str(Path.home() / ".elan" / "bin")
    env["PATH"] = f"{elan_bin}{os.pathsep}{env.get('PATH', '')}"
    env.pop("ALLOW_SKIP_LEAN_KERNEL", None)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"

    # 1. Verify SHA-256 Spec Lock & Reproducibility Manifest
    manifest_path = FORMAL_DIR / "spec_lock_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    for fname, expected in manifest.items():
        target = (
            FORMAL_DIR / "FactorForgeFormal" / "Spec.lean"
            if fname == "Spec.lean"
            else FORMAL_DIR / "FactorForgeFormal" / "Spec" / fname
        )
        actual = hashlib.sha256(target.read_bytes()).hexdigest().upper()
        if actual != expected.upper():
            raise SystemExit(f"SHA-256 lock mismatch on {fname}: {actual} != {expected}")
    print(f"[OK] Verified SHA-256 spec lock across {len(manifest)} specification files.")
    _verify_reproducibility_manifest()

    # 2. Clean & Build Lean 4 Package
    lake = _find_elan_bin("lake")
    leanchecker = _find_elan_bin("leanchecker")
    _run([lake, "clean"], cwd=FORMAL_DIR, env=env)
    _run([lake, "build"], cwd=FORMAL_DIR, env=env)

    # 3. Independent Kernel Verification (`leanchecker` replays full transitive closure of all 14 modules)
    _run([lake, "env", leanchecker, "FactorForgeFormal"], cwd=FORMAL_DIR, env=env)
    print("[OK] leanchecker verified FactorForgeFormal (all 14 modules) with exit 0.")

    # 4. Run Python Correspondence, Brute-Force Oracle, Property Fuzzer & Mutation Suite
    py_exe = FACTORFORGE_DIR / ".venv" / "Scripts" / "python.exe"
    python_cmd = str(py_exe) if py_exe.exists() else sys.executable
    _run([python_cmd, "-m", "pytest", "-v", str(TESTS_DIR)], cwd=ROOT, env=env)

    # 5. Multi-seed PYTHONHASHSEED determinism check on correspondence suite
    for seed in ("0", "1", "2", "3"):
        seed_env = dict(env)
        seed_env["PYTHONHASHSEED"] = seed
        _run(
            [
                python_cmd,
                "-m",
                "pytest",
                "-q",
                str(TESTS_DIR / "test_bruteforce_and_correspondence.py"),
                str(TESTS_DIR / "test_mutation_detection_audit.py"),
            ],
            cwd=ROOT,
            env=seed_env,
        )
    print("[OK] Multi-seed PYTHONHASHSEED=0..3 determinism verified.")

    # 6. Lint check via Ruff
    _run(
        [python_cmd, "-m", "ruff", "check", str(TESTS_DIR), str(ROOT / "verify_all.py")],
        cwd=ROOT,
        env=env,
    )
    print("[OK] All Lean 4 kernel, brute-force oracle, mutation, and lint checks passed.")


if __name__ == "__main__":
    main()
